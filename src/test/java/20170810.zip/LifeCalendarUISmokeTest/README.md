一：项目结构说明
目录结构：
LifeCalendarUISmokeTest
  |---src/test/java
       |---screen
           testcase
           testsuite
           util
  |---app
      log4j2.properties
      pom.xml

包详细说明：
screen:存放页面类，主要用于存放页面上显示的元素及页面相关的一些方法
testcase:存放测试用例，用来验证具体的用例结果
testsuite:测试组件，用来按顺序、批量执行测试
util:工具包，存放一些比较常规通用的一些方法,如建立连接、参数设置、FTP取包等

文件夹及文件说明：
app:FTP取包后存放的路径
target:运行maven测试自动生成的目录
example.log:log4j日志文件
pom.xml:maven工程配置文件，用来管理库依赖、运行测试等

二：运行测试
1、运行环境要求，参考appium环境要求
注意:
关于运行权限问题有2个解决办法，如下
1.1、运行UI自动化需要开发那边在AndroidManifest文件中将Activity 里面这个属性设置为真:android:exported="true",否则没有权限启动Activity
1.2、或者将手机root，然后安装一个adbd insecure应用，勾选里面的Enable insecure adbd

关于控件定位显示NAF：
通常都是由于这些控件是独立的，缺少相应的文本、内容描述，让开发那边添加文本描述或者内容描述信息即可识别

2、运行测试,进入工程中pom.xml文件所在目录 运行 mvn test(运行的测试用例需要以Test开头或者结尾)
或者指定测试组件运行：mvn surefire:test -Dtest=testsuite.FeatureTestSuite
ps:不在默认路径下注意带包名！
参考：http://maven.apache.org/surefire/maven-surefire-plugin/examples/single-test.html

运行单个测试方法：mvn -Dtest=TestCircle#mytest test
mvn test -Dtest=testsuite.FeatureTestSuite
 mvn test -Dtest=testcase.AboutUsCalendar_Android_1371Test#test1AboutUs运行某个测试类中的单个方法
三：新增测试
参考之前分享