package testcase;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import rule.TestName;
import screen.AbstractScreen;
import util.ScreenRecorder;

//实现登录操作并判断是否登录成功
public class DTLoginTest_Calendar_Android_297Test extends AbstractTest {

	public static Logger logger = Logger
			.getLogger(WBLoginTest_Calendar_Android_297Test.class);
	AbstractScreen as = new AbstractScreen(driver);
	@Rule
	public TestName name = new TestName();

	@Before
	public void setUp() {

		boolean alertWindow = false;// 权限提示框
		try {
			alertWindow = app.permissionScreen().alertWindow.isDisplayed();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (alertWindow) {
			app.permissionScreen().allow.click();// 运行获取权限
		}

		app.mainScreen().myPageTag.click();
		if (app.myScreen().isLogin()) {
			app.myScreen().enterLogOutPage();// 进入退出登录页面
			app.personalCenterScreen().logOut();// 退出登录
		}

	}

	@Test
	public void testDTLLogin() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isMapageTagDisypaly = false;
		isMapageTagDisypaly = as.waitElentAndCapture(
				app.mainScreen().myPageTag, "我的标签未显示");
		if (isMapageTagDisypaly) {
			app.mainScreen().myPageTag.click();
		}

		app.myScreen().enterLoginPage();

		app.loginScreen().login("apple00", "123456");

		boolean isInitNameDispaly = false;
		isInitNameDispaly = as.waitElentAndCapture(app.myScreen().initUserName,
				"没有找到登录用户名");
		if (isInitNameDispaly) {
			assertEquals(
					"期望值：apple00" + "实际值为:"
							+ app.myScreen().initUserName.getText(), "apple00",
					app.myScreen().initUserName.getText());
		}

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}