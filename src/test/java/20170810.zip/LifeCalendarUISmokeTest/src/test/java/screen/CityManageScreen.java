package screen;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

public class CityManageScreen extends AbstractScreen {

	public CityManageScreen(AppiumDriver<?> driver) {
		super(driver);
	}

	// 城市管理页面，城市显示面板(总)
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/gridview")
	private AndroidElement cityWindow;

	// 城市管理页面城市名的xpath控件定位
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.TextView[1]")
	private List<AndroidElement> cityName;

	// 添加城市按钮控件
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/addcity")
	private AndroidElement addCityButton;

	// 删除城市按钮，长按显示
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/delete")
	private List<AndroidElement> cityDeleteButton;

	// 删除城市按钮，长按显示
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/save")
	private AndroidElement confirmButton;

	// 城市管理页面，城市显示面板,包括天气城市
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(xpath = "//android.widget.GridView/android.widget.RelativeLayout")
	private List<AndroidElement> cityPanel;

	// 城市卡片
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id= "com.updrv.lifecalendar:id/ll_content")
	private List<AndroidElement> cityCard;

	public List<AndroidElement> getCityCard() {
		return cityCard;
	}

	public List<AndroidElement> getCityName() {
		return cityName;
	}

	public AndroidElement getAddCityButton() {
		return addCityButton;
	}

	public List<AndroidElement> getCityDeleteButton() {
		return cityDeleteButton;
	}

	public AndroidElement getConfirmButton() {
		return confirmButton;
	}

	public List<AndroidElement> getCityPanel() {
		return cityPanel;
	}

	List<String> beforeAddCityList = new ArrayList<String>();
	List<String> exList =new ArrayList<String>();//声明这个主要是为了转移城市列表
	public List<String> getExList() {
		return exList;
	}

	/**
	 * 获取添加前管理界面已存在的城市
	 * 
	 * @return 已存在的城市列表
	 */
	public List<String> getBeforeAddCityList() {

		for (int i = 0; i < cityName.size(); i++) {
			String cityList = cityName.get(i).getText();
			logger.info("城市管理界面已存在的城市为:" + cityList);
			beforeAddCityList.add(cityList);
            exList =beforeAddCityList;
		}

		return beforeAddCityList;
	}

	
	
	/**
	 * 判断城市列表长度
	 * 
	 * @return
	 */
	public int isInitialCityListFull() {

		int isCityFull = 1;

			if (cityName.size() >= 9 && cityName.size() < 12) {
			logger.info("城市数量不小于9个!");
	
			return isCityFull = 9;// 城市数量为9个或者以上
		} else {
			isCityFull = 2;
		}

		return isCityFull;
	}

	/**
	 * 添加城市
	 */
	public void addCity(List<String> beforeAddCityList, String selectedCity) {

		// 判断天气前城市数量是否为12
		boolean isCityListFull = isInitialCityListFull()==12?true:false;
		if (isCityListFull) {
			return;
		} else {
			addCityButton.click();// 进入添加页面
			if (compareCityRepeation(beforeAddCityList, selectedCity)) {
				logger.info("添加的城市已存在!");
				return;
			} else {

				AddCityScreen acs = new AddCityScreen(driver);
				acs.getAddCityButton().click();
				acs.getHotCityList().get(acs.CITY_POSTION).click();
			}

		}

	}

	/**
	 * 判断添加的城市是否已添加
	 * 
	 * @return
	 */
	public boolean compareCityRepeation(List<String> beforeAddCityList,
			String selectedCity) {
		boolean isCityAdded = false;// 先假设没有添加重复的城市
		for (int i = 0; i < beforeAddCityList.size(); i++) {
			logger.info("arraylist的长度为：" + beforeAddCityList.size());
			if (beforeAddCityList.get(i).contains(selectedCity)) {
				logger.info(selectedCity + "已添加!");
				isCityAdded = true;
			} else {
				logger.info("新增的城市为：" + selectedCity);
			}

		}
		return isCityAdded;
	}

	public void switchcity() {
		AndroidElement defaultCity = cityPanel.get(0);// 默认城市
		String defaultCityname = cityName.get(0).getText();// 获取默认城市名称
		// 要更换的城市
		AndroidElement changedCity = cityPanel.get(1);// 获取更换的城市
		String changedCityName = cityName.get(1).getText();// 获取要切换城市的名称
		TouchAction action = new TouchAction(driver);

		logger.info("正在切换城市...");
		action.longPress(changedCity).moveTo(defaultCity).release().perform();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		confirmButton.click();
		// 按返回键
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Assert.assertEquals(
		// changedCityName,
		//
		// .getText());

		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String new_position_cityName = driver.findElementById(
				"com.updrv.lifecalendar:id/tv_position_cityName").getText();
		Assert.assertEquals(changedCityName, new_position_cityName);
	}
}
