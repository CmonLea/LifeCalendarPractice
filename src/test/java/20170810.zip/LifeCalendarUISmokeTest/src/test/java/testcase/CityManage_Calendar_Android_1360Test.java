package testcase;

import java.io.IOException;
import java.util.List;

import io.appium.java_client.MobileElement;
import io.appium.java_client.SwipeElementDirection;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import rule.TestName;
import screen.AbstractScreen;
import testcase.AbstractTest;
import util.ScreenRecorder;

@SuppressWarnings("deprecation")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
// 方法按字典顺序执行
public class CityManage_Calendar_Android_1360Test extends AbstractTest {
	private static Logger logger = Logger
			.getLogger(CityManage_Calendar_Android_1360Test.class);
	AbstractScreen as = new AbstractScreen(driver);
	String selectedCity = null;

	@Rule
	// 使用TestName里的规则
	public TestName name = new TestName();

	@Before
	public void setUp() {
		Activity activity = new Activity("com.updrv.lifecalendar",
				".activity.weather.WeatherNewActivity");
		((AndroidDriver<?>) driver).startActivity(activity);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		// 进入城市管理页面添加城市
		boolean isElementDisplay = false;
		isElementDisplay = as.waitElentAndCapture(app.weatherScreen()
				.getCityAddButton(), "添加控件未找到");
		if (isElementDisplay) {
			app.weatherScreen().getCityAddButton().click();
		}

		List<String> beforeAddCityList = app.cityManageScreen()
				.getBeforeAddCityList();
		boolean isCity9 = app.cityManageScreen().isInitialCityListFull() == 9 ? true
				: false;
		if (isCity9) {
			// 城市数量>=9个时，需要向下滑动以添加城市，否则直接点击添加即可
			logger.info("滑动以获取添加按钮...");
			driver.swipe(100, 800, 100, 200, 500);
		}

		// 点击添加按钮
		try {
			boolean isAddButtonDisplay = app.cityManageScreen()
					.getAddCityButton().isDisplayed();
			if (isAddButtonDisplay) {
				app.cityManageScreen().getAddCityButton().click();

				// 添加时比较添加的城市是否已存在
				selectedCity = app.addCityScreen().addCity(beforeAddCityList);
			} else {
				logger.info("城市已满,无法添加！...");
				return;
			}

		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		// 表示添加的城市已存在
		if (selectedCity == null) {
			return;
		} else {
			List<String> afterAddCityList = app.cityManageScreen()
					.getBeforeAddCityList();
			int cityNum = afterAddCityList.size();
			logger.info("城市数量为：" + cityNum);
			((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	}

	// 1
	// 天气详情界面点击上方＋按钮
	//
	// 进入城市管理界面
	@Test
	public void testCityManagePage() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}

		boolean isElementDisplay = as.waitElentAndCapture(app.weatherScreen()
				.getCityAddButton(), "添加控件未找到");
		if (isElementDisplay) {
			app.weatherScreen().getCityAddButton().click();
		}

		String currentActivity = ((AndroidDriver<?>) driver).currentActivity();
		Assert.assertEquals("期望值为：.activity.weather.CityManagerActivity"
				+ "实际值为：" + currentActivity,
				".activity.weather.CityManagerActivity", currentActivity);
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 2
	// 手动添加不同的城市，返回天气详情界面，左右滑动界面
	//
	// 切换城市天气信息数据正常

	@Test
	// @Ignore
	public void testCityManagePageAddCity() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 点击天气上的城市进入城市管理页面
		boolean isElementDisplay = false;
		isElementDisplay = as.waitElentAndCapture(app.weatherScreen()
				.getCityAddButton(), "添加控件未找到");
		if (isElementDisplay) {
			app.weatherScreen().getCityAddButton().click();
		} else {
			logger.info("................");
		}

		List<String> beforeAddCityList = app.cityManageScreen()
				.getBeforeAddCityList();
		boolean isCity9 = app.cityManageScreen().isInitialCityListFull() == 9 ? true
				: false;
		if (isCity9) {
			// 城市数量>=9个时，需要向下滑动以添加城市，否则直接点击添加即可
			logger.info("滑动以获取添加按钮...");
			driver.swipe(100, 800, 100, 200, 500);
		}

		// 点击添加按钮
		try {
			boolean isAddButtonDisplay = app.cityManageScreen()
					.getAddCityButton().isDisplayed();
			if (isAddButtonDisplay) {
				app.cityManageScreen().getAddCityButton().click();

				// 添加时比较添加的城市是否已存在
				selectedCity = app.addCityScreen().addCity(beforeAddCityList);
			} else {
				logger.info("城市已满,无法添加！...");
				return;
			}

		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		// 表示添加的城市已存在

		List<String> afterAddCityList = app.cityManageScreen()
				.getBeforeAddCityList();
		int cityNum = afterAddCityList.size();
		logger.info("城市数量为：" + cityNum);
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		// 添加城市后返回到天气页面
		for (int i = 0; i < cityNum; i++) {
			// 向左滑动获取最后一个城市
			boolean isWeatherAreaDisplay = false;
			isWeatherAreaDisplay = as.waitElentAndCapture(app.weatherScreen()
					.getMainWeatherArea(), app.weatherScreen()
					.getMainWeatherArea().toString());
			if (isWeatherAreaDisplay) {
				// 待完善
				// app.weatherScreen().getMainWeatherArea()
				// .swipe(SwipeElementDirection.LEFT, 50, 50, 500);
				// (( AndroidDriver<?>) driver).swipe(startx, starty, endx,
				// endy, duration);
				as.swipeWidget2Left((AndroidDriver<?>) driver, app
						.weatherScreen().getMainWeatherArea(), 0);
			}

			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
		boolean isAddButtonDisplay = false;
		isAddButtonDisplay = as.waitElentAndCapture(app.weatherScreen()
				.getCityAddButton(), app.weatherScreen().getCityAddButton()
				.toString());
		String cityName = null;
		if (isAddButtonDisplay) {
			cityName = app.weatherScreen().getCityAddButton().getText();
			logger.info("添加的城市为：" + cityName);
			Assert.assertEquals("期望添加的城市为:" + selectedCity + "实际为:" + cityName,
					selectedCity, cityName);

		}

	
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 3
	// 城市管理界面，长按，拖动非定位城市到首位，返回主界面
	//
	// 主界面显示的是所选择的第一个城市的天气信息
	@Test
	// @Ignore
	public void testCityManagePageChangeCity() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}

		String currentActivity = ((AndroidDriver<?>) driver).currentActivity();
		logger.info("当前页面为" + currentActivity);
		if (currentActivity.equals(".activity.weather.WeatherNewActivity")) {
			logger.info("当前界面为天气界面");
			// 前提最少有2个城市才能切换
			boolean isAddButtonDisplay = false;
			isAddButtonDisplay = as.waitElentAndCapture(app.weatherScreen()
					.getCityAddButton(), "添加控件未找到");
			logger.info("进入城市管理按钮显示为" + isAddButtonDisplay);
			if (isAddButtonDisplay) {
				logger.info("天气界面添加按钮已显示,正在点击进入城市管理页面");
				app.weatherScreen().getCityAddButton().click();

			}

		}

		AndroidElement defaultCity = null;
		// 要更换的城市
		AndroidElement changedCity = null;
		String changedCityName = null;
		String defaultCityname = null;
		try {

			defaultCity = app.cityManageScreen().getCityPanel().get(0);
			defaultCityname = app.cityManageScreen().getCityName().get(0)
					.getText();// 获取默认城市名称
			changedCity = app.cityManageScreen().getCityPanel().get(1);
			changedCityName = app.cityManageScreen().getCityName().get(1)
					.getText();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		TouchAction action = new TouchAction(driver);

		logger.info("正在切换城市...");
		if (changedCity != null && defaultCity != null) {
			action.longPress(changedCity).moveTo(defaultCity).release()
					.perform();
		}

		// 按返回键

		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}

		Assert.assertNotEquals(defaultCityname, app.weatherScreen()
				.getCityAddButton().getText());
		Assert.assertEquals(changedCityName,

		app.weatherScreen().getCityAddButton().getText());

		// 获取首页显示的天气插件中城市的名称
		// 返回到主界面查看是否切换成功
		Activity activity = new Activity("com.updrv.lifecalendar",
				".activity.MainActivity");
		((AndroidDriver<?>) driver).startActivity(activity);
		// 滑动日历控件
		// app.mainScreen().swipeWidget2Up(app.mainScreen().calendarScreen,
		// "日历页面", 500);
		boolean isCalendarDisplayas = as.waitElentAndCapture(
				app.mainScreen().calendarScreen,
				app.mainScreen().calendarScreen.toString());
		if (isCalendarDisplayas) {
			as.swipeWidget2Up((AndroidDriver<?>) driver,
					app.mainScreen().calendarScreen, 500);
		}

		// 滑动黄历控件
		// app.mainScreen().swipeWidget2Up(app.mainScreen().almanacWidget,
		// "黄历页面",
		// 500);
		as.swipeWidget2Up((AndroidDriver<?>) driver,
				app.mainScreen().almanacWidget, 0);
		String new_position_cityName = null;
		try {
			boolean isWeatherPlugDisPlay = as.waitElentAndCapture(app
					.mainScreen().getWeatherPlugCityName(), "日历首页天气未显示异常");
			if (isWeatherPlugDisPlay) {
				new_position_cityName = app.mainScreen()
						.getWeatherPlugCityName().getText();
				Assert.assertEquals(changedCityName, new_position_cityName);
			}

		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	// 4
	// 长按已添加的非定位城市，当显示删除按钮“X”是执行删除操作
	//
	// 城市正常删除，天气信息中不存在删除城市的气象信息。

	@Test
	// @Ignore
	public void testCityManagePageDeleteCity() {
		// com.updrv.lifecalendar/.activity.weather.CityManagerActivity

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isAddButtonDisplay = false;
		isAddButtonDisplay = as.waitElentAndCapture(app.weatherScreen()
				.getCityAddButton(), "查找天气界面添加按钮");
		if (isAddButtonDisplay) {
			app.weatherScreen().getCityAddButton().click();
			List<String> cityList1 = app.cityManageScreen()
					.getBeforeAddCityList();

			MobileElement me = app.cityManageScreen().getCityCard().get(1);

			me.tap(1, 800);

			logger.info("删除的城市为：" + cityList1.get(1));
			// logger.info("==========="+me.getText());
			boolean isDelenteCityButtonDisyplay = false;
			try {
				isDelenteCityButtonDisyplay = app.cityManageScreen()
						.getCityDeleteButton().get(1).isDisplayed();
			} catch (Exception e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			if (isDelenteCityButtonDisyplay) {// 如果删除按钮显示则执行删除操作
				logger.info("正在执行删除操作，请稍等...");
				app.cityManageScreen().getCityDeleteButton().get(1).click();
				logger.info("删除城市完毕！");
				List<String> cityList2 = app.cityManageScreen()
						.getBeforeAddCityList();
				Assert.assertTrue("cityList2中不包含删除的城市：" + cityList1.get(1),
						!cityList2.contains(cityList1.get(1)));

			} else {
				logger.error("没有找到删除按钮，请确认是否触发长按操作");
				as.takeScreenShot("没有找到城市删除按钮");
			}

		}
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}
//	@After
//	public void tearDownCity() {
//		logger.info("正在清理测试环境...");
//		try {
//			Runtime.getRuntime().exec(
//					"adb shell pm clear com.updrv.lifecalendar");
//
//			try {
//				Thread.sleep(10 * 1000);
//			} catch (InterruptedException e) {
//
//				e.printStackTrace();
//			}
//		} catch (IOException e) {
//
//			e.printStackTrace();
//		}
//	}
}
