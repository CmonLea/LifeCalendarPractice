package screen;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.StartsActivity;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyScreen extends AbstractScreen {

	public MyScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/account_info")
	// 用户信息展示控件id
	public AndroidElement accountInfo;// 登录用，不能用来获取用户名
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/ll_to_personal_edit")
	// 修改个人资料按钮控件id
	public WebElement personalInfo;
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/tv_personal_account_user_name")
	public WebElement initUserName;
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(className = "android.widget.ImageView")
	public List<WebElement> loginButton;
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/dialog_text")
	// 温馨提示
	public WebElement remindWindow;
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/dialog_text3")
	// 稍后再说确人按钮
	public WebElement remindLaterButton;
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="com.updrv.lifecalendar:id/rel_personal_account_setting")
	private AndroidElement systemSetting;

	
	// 我的页面关于我们
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/rel_personal_account_time_about")
	private AndroidElement aboutUsItem;

	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="com.updrv.lifecalendar:id/rel_personal_account_opinion")
	private AndroidElement optionFeed;
	
	public AndroidElement getOptionFeed() {
		return optionFeed;
	}

	public AndroidElement getSystemSetting() {
		return systemSetting;
	}

	// 我的页面给我好评
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/rel_personal_account_give")
	private AndroidElement goodComment;

	public AndroidElement getGoodComment() {
		return goodComment;
	}

	public AndroidElement getAboutUs() {
		return aboutUsItem;
	}

	// 判断是否登录，返回获取的用户名
	public boolean isLogin() {
		String userName = null;
		boolean loginStatus=false;
		// PropertyConfigurator.configure("log4j2.properties");
		boolean isInitNameDis =false;
		isInitNameDis =waitElentAndCapture(initUserName, "未找到登录初始用户名");
		if(isInitNameDis){
			userName = initUserName.getText();
			loginStatus = userName.equals("未登录");
		}
		
		
		if (loginStatus) {
			// System.out.println("用户未登录");
			logger.info("用户未登录");
			loginStatus = false;
		} else {
			// System.out.println("用户已登录");
			logger.info("用户已登录");

			loginStatus = true;

		}
		return loginStatus;

	}

	@Override
	public void resetAPP() {
		// System.out.println("重置APP...");
		logger.info("重置App...");
		driver.resetApp();
		Activity ac = new Activity("com.updrv.lifecalendar",
				".activity.MainActivity");
		((StartsActivity) driver).startActivity(ac);
	}

	public void enterLogOutPage() {
		logger.info("退出登录...");
		try {
			personalInfo.click();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		// driver.findElementByName("确定").click();
	}

	// 进入登录页面
	public void enterLoginPage() {
		logger.info("进入登录页面");
		try {
			accountInfo.click();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}
