package testcase;

import java.io.IOException;

import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.NoSuchElementException;

import rule.TestName;
import screen.AbstractScreen;
import testcase.AbstractTest;
import util.ScreenRecorder;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
// 方法按字典顺序执行
public class HistoryToday_Calendar_Android_1048Test extends AbstractTest {
	public static Logger logger = Logger
			.getLogger(HistoryToday_Calendar_Android_1048Test.class);
	AbstractScreen as = new AbstractScreen(driver);

	@Rule
	public TestName name = new TestName();

	// 步骤：日历主界面点击“历史的今天”
	// 期望：进入到历史今天的详情界面
	@Test
	public void testHistoryDetailPage() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 进入到历史今天页面
//		app.mainScreen().swipeWidget2Up(app.mainScreen().calendarScreen,
//				"日历控件", 500);
		as.swipeWidget2Up((AndroidDriver<?>)driver,app.mainScreen().calendarScreen , 500);
		
		// 判断历史今天控件是否显示
		AndroidElement hisWidget = app.mainScreen().historyWidget;
		boolean isHistoryDisplay = false;
		isHistoryDisplay = app.mainScreen().isWidgetDisplay(hisWidget);
		if (isHistoryDisplay) {
			logger.info("进入日历就显示了历史今天控件直接点击...");
			app.mainScreen().historyWidget.click();
		} else {
			logger.info("进入日历没有显示了历史今天控件正在滑动...");
			boolean isAlmanacWidget = false;
			isAlmanacWidget = as
					.isWidgetDisplay(app.mainScreen().almanacWidget);
			if (isAlmanacWidget) {
//				app.mainScreen().swipeWidget2Up(app.mainScreen().almanacWidget,
//						"黄历控件", 500);
				as.swipeWidget2Up((AndroidDriver<?>)driver,app.mainScreen().almanacWidget , 500);
				isHistoryDisplay = app.mainScreen().isWidgetDisplay(hisWidget);
				if (isHistoryDisplay) {
					logger.info("滑动黄历后显示了历史今天控件直接点击...");
					app.mainScreen().historyWidget.click();
				} else {
					logger.info("滑动黄历后没有显示历史今天插件...");
				}

			}
			// 广告插件
			boolean isAdDisplayed = false;
			isAdDisplayed = as.isWidgetDisplay(app.mainScreen().advertisement);
			if (isAdDisplayed) {
				logger.info("显示了广告模块,正在滑动...");
//				app.mainScreen().swipeWidget2Up(app.mainScreen().advertisement,
//						"广告控件", 500);
				
				as.swipeWidget2Up((AndroidDriver<?>) driver,
						app.mainScreen().advertisement, 0);
				isHistoryDisplay = app.mainScreen().isWidgetDisplay(hisWidget);
				if (isHistoryDisplay) {
					logger.info("滑动广告后显示了历史今天控件直接点击...");
					app.mainScreen().historyWidget.click();
				} else {
					logger.info("滑动广告后没有显示历史今天插件...");
				}

			} else {
				// 天气插件
				boolean isweatherWidgetDisplay = false;

				isweatherWidgetDisplay = as
						.isWidgetDisplay(app.mainScreen().weatherWidget);
				if (isweatherWidgetDisplay) {
//					app.mainScreen().swipeWidget2Up(
//							app.mainScreen().weatherWidget, "天气控件", 500);
					
					as.swipeWidget2Up((AndroidDriver<?>) driver,
							app.mainScreen().weatherWidget, 0);
					isHistoryDisplay = app.mainScreen().isWidgetDisplay(
							hisWidget);
					if (isHistoryDisplay) {
						logger.info("滑动天气后显示了历史今天控件直接点击...");
						app.mainScreen().historyWidget.click();
					} else {
						logger.info("滑动天气后没有显示历史今天插件...");
					}
				}
			}

			boolean isHoroDisplay = false;
			isHoroDisplay = as
					.isWidgetDisplay(app.mainScreen().horoscopeWidget);
			if (isHoroDisplay) {
//				app.mainScreen().swipeWidget2Up(
//						app.mainScreen().horoscopeWidget, "星座控件", 500);
                as.swipeWidget2Up((AndroidDriver<?>)driver, app.mainScreen().horoscopeWidget, 0);
				isHistoryDisplay = app.mainScreen().isWidgetDisplay(hisWidget);
				if (isHistoryDisplay) {
					logger.info("滑动星座后显示了历史今天控件直接点击...");
					app.mainScreen().historyWidget.click();
				} else {
					logger.info("滑动星座后没有显示历史今天插件...正在滑动公众提醒...");
					int i = 0;
					while (!isHistoryDisplay) {
						logger.info("滑动不到位,正在继续滑动...当前尝试第" + (i + 1) + "次");
						app.mainScreen().swipeFullRemind2Up();
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO 自动生成的 catch 块
							e.printStackTrace();
						}

						isHistoryDisplay = app.mainScreen().isWidgetDisplay(
								hisWidget);
						if (i == 10) {
							logger.info("尝试10次无果...");
							break;
						}
						if (isHistoryDisplay) {
							break;
						}

						i++;
					}

					if (isHistoryDisplay) {
						app.mainScreen().historyWidget.click();
					} else {
						as.takeScreenShot("没有找到历史今天控件");
						throw new NoSuchElementException("没有找到历史今天控件");

					}

				}
			} else {
				throw new NoSuchElementException("没有找到历史今天控件");
			}

		}
		// 获取当前Activity
		String currentActivity = ((AndroidDriver<?>) driver).currentActivity();

		Assert.assertEquals("期望值为：.activity.HistoryTodayActivity" + "实际值为："
				+ currentActivity, ".activity.HistoryTodayActivity",
				currentActivity);

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 步骤：历史详情界向下滑动
	//
	// 期望：正常滑动显示历史上今天的信息列表
	@Test
	public void testHistoryDetailPageDown() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}

		String currentActivity = ((AndroidDriver<?>) driver).currentActivity();
		if (currentActivity == ".activity.HistoryTodayActivity") {

		} else {
			Activity activity = new Activity("com.updrv.lifecalendar",
					".activity.HistoryTodayActivity");
			((AndroidDriver<?>) driver).startActivity(activity);
		}
		// 获取历史今天列表第一条数据控件
		String fristItemInfoBeforeSwipe = app.historyTodayScreen().itemContent
				.get(0).getText();

		app.historyTodayScreen().swipeHistoryList();

		String fristItemInfoAfterSwipe = app.historyTodayScreen().itemContent
				.get(0).getText();
		// 首次进入显示的头条信息与滑动后的信息不同
		Assert.assertNotEquals("初始显示信息为：" + fristItemInfoBeforeSwipe
				+ "滑动后信息为：" + fristItemInfoAfterSwipe,
				fristItemInfoBeforeSwipe, fristItemInfoAfterSwipe);

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	// 步骤： 点击列表中的任一信息
	//
	// 期望：正常加载信息页面，页面内容显示正常
	//
	@Test(timeout = 90 * 1000)
	@Ignore
	public void testHistoryDetailPageListClikInfo() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 历史今天页面
		Activity activity = new Activity("com.updrv.lifecalendar",
				".activity.HistoryTodayActivity");
		((AndroidDriver<?>) driver).startActivity(activity);
		app.historyTodayScreen().swipeAndClick();
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}
}
