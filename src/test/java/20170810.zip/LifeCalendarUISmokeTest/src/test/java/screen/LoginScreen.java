package screen;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginScreen extends AbstractScreen {

	public LoginScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	// 160
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(className = "android.widget.EditText")
	List<WebElement> accountEditText;
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(className = "android.widget.EditText")
	List<WebElement> passwordEditText;
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(className = "android.widget.Button")
	WebElement loginButton;

	// 公共区域按钮
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/tv_register")
	public WebElement accoutRegisterBtn;

	// QQ
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/qq_login")
	WebElement qqLoginButton;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(className = "input_id")
	WebElement input_id;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(className = "input_pwd")
	WebElement input_pwd;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "go")
	WebElement go;

	// 微博
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/web_login")
	WebElement wbButton;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(name = "userId")
	WebElement uEditText;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(name = "passwd")
	WebElement pEditText;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(className = "btnP")
	WebElement btnP;
	
	

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(xpath = "//*[@id=\"outer\"]/div[1]/section/div[2]/form/div/div[3]")
	WebElement codecon;
	

	public void login(String userName, String passWord)
			throws NoSuchElementException {
         logger.info("登录的账号用户名为："+userName+"密码为："+passWord);
		try {
			if (accountEditText.get(0).isDisplayed()) {
				accountEditText.get(0).sendKeys(userName);
			} else {
				logger.error("进行异常截图...");
				waitElentAndCapture(accountEditText.get(0), "用户输入框未找到");

			}
			if (passwordEditText.get(1).isDisplayed()) {
				passwordEditText.get(1).sendKeys(passWord);
			} else {
				logger.error("进行异常截图...");
				waitElentAndCapture(passwordEditText.get(1), "密码输入框未找到");

				// takeScreenShot("密码输入框未找到异常");

			}
			if (loginButton.isDisplayed()) {
				findElementWithTimeout(loginButton).click();
			} else {
				logger.error("进行异常截图...");
				waitElentAndCapture(passwordEditText.get(1), "登录按钮未找到");

				// takeScreenShot("登录按钮未找到异常");

			}
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	public void qqLogin(String userName, String passWord) {
		// boolean isqqinstalled =
		// driver.isAppInstalled("com.tencent.mobileqq");
		//
		// if (isqqinstalled) {
		// driver.removeApp("com.tencent.mobileqq");
		// }

		try {
			boolean isQqLoginButtonDisplay;
			isQqLoginButtonDisplay = waitElentAndCapture(qqLoginButton,
					"QQ登录按钮未显示");
			if (isQqLoginButtonDisplay) {
				logger.info("切换到QQ登录页面...");
				qqLoginButton.click();
			}

			//Set<String> contexts = driver.getContextHandles();

//			for (String context : contexts) {
//				// System.out.println(context); // it will print NATIVE_APP \n
//				logger.info(context); // WEBVIEW_com.example.testapp
//			}
			// takeScreenShot("QQ��¼ǰ");

			driver.context("WEBVIEW_com.updrv.lifecalendar");

			// driver.context("NATIVE_APP");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			boolean isInputIdDisplay = false;
			isInputIdDisplay = waitElentAndCapture(input_id, "QQ输入框未显示");

			boolean isInputPwdDisplay;
			isInputPwdDisplay = waitElentAndCapture(input_id, "QQ密码输入框未显示");

			boolean isGoButtonDisplay = false;
			isGoButtonDisplay = waitElentAndCapture(go, "QQ网页登录按钮未显示");

			if (isInputIdDisplay && isInputPwdDisplay && isGoButtonDisplay) {
				input_id.sendKeys(userName);

				input_pwd.sendKeys(passWord);

				go.click();
			}

			Thread.sleep(5000);
			driver.context("NATIVE_APP");
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	public void weiboLogin(String userName, String passWord) {

		try {
			wbButton.click();
			//Thread.sleep(3000);

			Set<String> contexts = driver.getContextHandles();
			for (String context : contexts) {
				logger.info(context);
			}

			driver.context("WEBVIEW_com.updrv.lifecalendar");
			//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			AbstractScreen as =new AbstractScreen(driver);
			
			boolean isUTextDisplay=false;
			isUTextDisplay =as.waitElentAndCapture(uEditText, "查找微博登录输入框");
			if(isUTextDisplay){
				 
				uEditText.sendKeys(userName);
				pEditText.sendKeys(passWord);

			}
			boolean isCodeDisplay=false;
			isCodeDisplay =as.waitElentAndCapture(codecon,codecon.toString());
			if(isCodeDisplay){
				logger.warn("显示了验证码无法继续操作");
				as.takeScreenShot(codecon.toString());
			}
          
			btnP.click();
			Thread.sleep(15000);
			// Assert.assertEquals("RelicRun",
			// driver.findElementById("").getText());

			driver.context("NATIVE_APP");
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		//
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}



}
