package screen;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class FeedBackScreen extends AbstractScreen {

	public FeedBackScreen(AppiumDriver<?> driver) {
		super(driver);
	}
    //反馈内容列表
	@FindBy(id = "com.updrv.lifecalendar:id/txt_fbitem_feedcontent")
	List<AndroidElement> feedContent;

	public List<AndroidElement> getFeedContent() {
		return feedContent;
	}

	public AndroidElement getFeedEdit() {
		return feedEdit;
	}

	public AndroidElement getSendButton() {
		return sendButton;
	}
	//反馈文本框
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/feedback_content_et")
	AndroidElement feedEdit;
	
	//发送按钮
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="com.updrv.lifecalendar:id/feedback_send_btn")
	AndroidElement sendButton;
	
	//发送按钮
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="com.updrv.lifecalendar:id/pulltorefreshviewfeedback")
	AndroidElement feedBackWindow;
	
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="com.updrv.lifecalendar:id/txt_fbitem_indate")
	List<AndroidElement> sendTime;

	public List<AndroidElement> getSendTime() {
		return sendTime;
	}

	public AndroidElement getFeedBackWindow() {
		return feedBackWindow;
	}

	
}
