package screen;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

//添加城市页面
public class AddCityScreen extends AbstractScreen {

	public static Logger logger = Logger.getLogger(AddCityScreen.class);
    public int CITY_POSTION = (int) (Math.random() * 31 + 1);// 32个热门城市

	//public int CITY_POSTION = 1;

	public AddCityScreen(AppiumDriver<?> driver) {
		super(driver);
		// TODO 自动生成的构造函数存根
	}

	// 设置5s的延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	// 添加城市页面添加按钮
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/addcity")
	private AndroidElement addCityButton;

	// 设置5s的延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	// 添加城市页面城市名称
	@AndroidFindBy(xpath = "//android.widget.GridView/android.widget.LinearLayout/android.widget.TextView")
	private List<AndroidElement> hotCityList;

	public List<AndroidElement> getHotCityList() {
		return hotCityList;
	}

	public AndroidElement getAddCityButton() {
		return addCityButton;
	}

	String selectedCity = hotCityList.get(CITY_POSTION).getText();
	// 实例化城市管理页面获取添加城市前存在的城市列表
	CityManageScreen cms = new CityManageScreen(driver);

	/**
	 * 添加城市
	 */
	public String addCity(List<String> beforeAddCityList) {

		// 如果已添加则添加一个新城市

		// // 判断天气前城市数量是否为12
		//
		// // addCityButton.click();// 进入添加页面
		if (compareCityRepeation(beforeAddCityList, selectedCity)) {
			logger.info("添加的城市已存在,正在重新生成坐标！");
			int newpostion=0;
			while (compareCityRepeation(beforeAddCityList, selectedCity)) {
				// 如果城市管理界面已存在选择的城市则重新获取城市
				logger.info("正在重新生成城市坐标...");
				 newpostion= (int) (Math.random() * 31 + 1);
				selectedCity = hotCityList.get(newpostion).getText();
				// 如果新获取的城市不在已添加的城市管理页面则退出
				if (compareCityRepeation(beforeAddCityList, selectedCity)) {
					logger.info("选择的城市未重复退出当前判断...");
					break;
				}
			}
			logger.info("正在添加新城市...");
			hotCityList.get(newpostion).click();
			cms.exList.add(selectedCity);// 将新增的城市转移到新List中，因为隐藏的城市无法读取
			logger.info("新增的城市为：" + selectedCity);
		} else {
			hotCityList.get(CITY_POSTION).click();
			cms.exList.add(selectedCity);// 将新增的城市转移到新List中，因为隐藏的城市无法读取
			logger.info("新增的城市为：" + selectedCity);
		}
		return selectedCity;

	}

	/**
	 * 判断添加的城市是否已添加
	 * 
	 * @return
	 */
	public boolean compareCityRepeation(List<String> beforeAddCityList,
			String selectedCity) {
		boolean isCityAdded = false;// 先假设没有添加重复的城市
		// logger.info("arraylist的长度为：" + beforeAddCityList.size());

		if (beforeAddCityList.contains(selectedCity)) {
			logger.info(selectedCity + "已添加!");
			isCityAdded = true;
			return isCityAdded;
		} else {
			logger.info("新增的城市为：" + selectedCity);
		}

		return isCityAdded;
	}

}
