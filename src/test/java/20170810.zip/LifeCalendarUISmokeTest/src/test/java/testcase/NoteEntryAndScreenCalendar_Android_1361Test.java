package testcase;

import java.io.IOException;
import java.util.List;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.Result;
import org.junit.runners.MethodSorters;

import rule.TestName;
import screen.AbstractScreen;
import util.ScreenRecorder;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NoteEntryAndScreenCalendar_Android_1361Test extends AbstractTest {
	private static Logger logger = Logger
			.getLogger(NoteEntryAndScreenCalendar_Android_1361Test.class);

	AbstractScreen as = new AbstractScreen(driver);

	@Rule
	public TestName name = new TestName();

	@Before
	// @Ignore
	public void setUpForNotes() {
		boolean isMyPageTag = false;
		isMyPageTag = as.waitElentAndCapture(app.mainScreen().myPageTag,
				"我的标签未显示");
		if (isMyPageTag) {
			app.mainScreen().myPageTag.click();
		}

		if (app.myScreen().isLogin()) {
			app.myScreen().enterLogOutPage();// 进入退出登录页面
			app.personalCenterScreen().logOut();// 退出登录
		}

		app.mainScreen().myPageTag.click();

		app.myScreen().enterLoginPage();

		app.loginScreen().login("apple04", "123456");

	}

	// 步骤：
	// 1.点击记事进入记事列表
	// 期望：
	// 1.跳转到普通记事界面，显示搜索，新建按钮
	//
	// 2.记事排序默认按月份排序，排序正确
	@Test
	// @Ignore("NAF元素需要开发配合修改后才能通过")
	public void test1EnterNoteList() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isRemindPageTagDisPlay = false;
		isRemindPageTagDisPlay = as.waitElentAndCapture(
				app.mainScreen().remindPageTag,
				app.mainScreen().remindPageTag.toString());
		if (isRemindPageTagDisPlay) {
			app.mainScreen().remindPageTag.click();
		}

		app.remindScreen().noteItem.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		String expectedActivity = ".activity.recordthing.NoteListActivity";
		String actualActivity = ((AndroidDriver<?>) driver).currentActivity();

		Assert.assertEquals("期望跳转页面为：" + expectedActivity + "实际为："
				+ actualActivity, expectedActivity, actualActivity);
		boolean isSeachButtonDisplay = false;
		boolean isAddButtonDisplay = false;
		isAddButtonDisplay = as.isWidgetDisplay((AndroidElement) (app
				.noteScreen().getNewButton()));

		isSeachButtonDisplay = as.isWidgetDisplay((AndroidElement) (app
				.noteScreen().getSearchButton()));
		// NAF元素需要开发配合修改后才能通过
		Assert.assertTrue("期望新增记事按钮显示为true实际为：" + isAddButtonDisplay,
				isAddButtonDisplay);
		// NAF元素需要开发配合修改后才能通过
		Assert.assertTrue("期望搜索按钮显示为true实际为：" + isSeachButtonDisplay,
				isSeachButtonDisplay);
		List<String> noteList = app.noteScreen().getNoteListDate();
		// for (int i = 0; i < noteList.size(); i++) {
		// logger.info("************" + noteList.get(i));
		// }
		//
		// Date date = new Date();
		// SimpleDateFormat sdf = new SimpleDateFormat("YYYY年MM月");
		// String formatDate = sdf.format(date);
		// DateFormat df = DateFormat.getDateInstance();

		for (int i = 0; i < noteList.size(); i++) {
			for (int j = i + 1; j < noteList.size(); j++) {

				// boolean firstBigThantwo = false;
				// app.noteScreen();
				int dateOrder = AbstractScreen.compare_date(noteList.get(i),
						noteList.get(j));
				//
				Assert.assertEquals(1, dateOrder);
			}
		}
		// 退出记事页面
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 步骤：
	// 点击待办、日程
	//
	// 勾选/取消勾选未完成的待办记事

	// 期望：
	// 1.显示待办和日程2个分类，切换正常
	//
	// 2.勾选显示为已完成，取消勾选显示为未完成
	//
	// 3.日程记事内容和排序正确-----此条未验证

	@Test
	// @Ignore("NAF元素需要开发配合修改后才能通过")
	public void test2Schedule() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		logger.info("验证待办日程...");

		boolean isRemindTagDis = false;
		isRemindTagDis = as.waitElentAndCapture(app.mainScreen().remindPageTag,
				"提醒标签未显示");
		// 后面用反射获取到失败方法的完整名称
		if (isRemindTagDis) {
			app.mainScreen().remindPageTag.click();
		}
		// app.mainScreen().remindPageTag.click();
		boolean isBackLogScheduleDisplay = false;
		isBackLogScheduleDisplay = as.waitElentAndCapture(
				app.remindScreen().backlogScheduleItem,
				app.remindScreen().backlogScheduleItem.toString());

		if (isBackLogScheduleDisplay) {
			app.remindScreen().backlogScheduleItem.click();
		}

		String expectedActivity = ".activity.recordthing.ScheduleListActivity";
		String actualActivity = ((AndroidDriver<?>) driver).currentActivity();
		Assert.assertEquals("期望跳转页面为：" + expectedActivity + "实际为："
				+ actualActivity, expectedActivity, actualActivity);
		// NAF元素需要开发配合修改后才能通过
		boolean isReadyDoDisplay = false;
		boolean ischeduleDisplay = false;
		isReadyDoDisplay = as
				.isWidgetDisplay((app.scheduleScreen().getReadDo()));

		ischeduleDisplay = as.isWidgetDisplay((app.scheduleScreen()
				.getSchedule()));
		Assert.assertTrue("期望待办显示为true实际为：" + isReadyDoDisplay,
				isReadyDoDisplay);
		Assert.assertTrue("期望日程显示为true实际为：" + ischeduleDisplay,
				ischeduleDisplay);
		// NAF元素需要开发配合修改后才能通过
		boolean isStatusNameDis = false;
		isStatusNameDis = as.waitElentAndCapture(app.scheduleScreen()
				.getStatusName(), "没有找到待办状态名称");
		String statusName = null;
		if (isStatusNameDis) {
			statusName = app.scheduleScreen().getStatusName().getText();
		} else {
			isStatusNameDis = as.waitElentAndCapture(app.scheduleScreen()
					.getStatusName(), "没有找到待办状态名称");
			if (isStatusNameDis) {
				statusName = app.scheduleScreen().getStatusName().getText();
			}
		}

		logger.info("statusName:" + statusName);

		// 判断初始状态
		if (statusName.equals("已经完成") && statusName != null) {
			// ta.tap(checkButtonX, checkButtonY);
			// app.scheduleScreen().getReadDoChekButton().click();
			app.scheduleScreen().getReadDoChekButton().click();
			statusName = app.scheduleScreen().getStatusName().getText();

			Assert.assertEquals("期望完成状态为未完成，实际为：" + statusName, "未完成",
					statusName);

		}

		if (statusName.equals("未完成") && statusName != null) {
			// ta.tap(checkButtonX, checkButtonY);
			app.scheduleScreen().getReadDoChekButton().click();
			statusName = app.scheduleScreen().getStatusName().getText();

			Assert.assertEquals("期望完成状态为已经完成，实际为：" + statusName, "已经完成",
					statusName);
		}
		// 退出记事页面
		app.scheduleScreen().getBackButton().click();
		// ((AndroidDriver<?>)driver).pressKeyCode(AndroidKeyCode.BACK);

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	// 步骤：
	// 点击提醒
	//
	// 期望：
	// 跳转到提醒记事界面，显示搜索和＋按钮
	//
	// 内容和排序正确（相同年份按月排序）
	@Test
	// @Ignore
	public void test3Remind() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		logger.info("验证提醒...");
		// Activity ac = new Activity("com.updrv.lifecalendar",
		// ".activity.remind.RemindListActivity");
		//
		// // 启动生日纪念日页面
		// ((StartsActivity) driver).startActivity(ac);
		boolean isRemindTagDis = false;
		isRemindTagDis = as.waitElentAndCapture(app.mainScreen().remindPageTag,
				"提醒标签未显示");
		// 后面用反射获取到失败方法的完整名称
		if (isRemindTagDis) {
			app.mainScreen().remindPageTag.click();
		}
		boolean isRemindItemDisplay = false;
		isRemindItemDisplay = as.waitElentAndCapture(
				app.remindScreen().remindItem, Result.class.getCanonicalName());
		if (isRemindItemDisplay) {
			app.remindScreen().remindItem.click();
		}

		String expectedActivity = ".activity.remind.RemindListActivity";
		String actualActivity = ((AndroidDriver<?>) driver).currentActivity();
		Assert.assertEquals("期望跳转页面为：" + expectedActivity + "实际为："
				+ actualActivity, expectedActivity, actualActivity);
		boolean isSeachButtonDisplay = false;
		boolean isAddButtonDisplay = false;
		isAddButtonDisplay = as.isWidgetDisplay((AndroidElement) (app
				.noteScreen().getNewButton()));

		isSeachButtonDisplay = as.isWidgetDisplay((AndroidElement) (app
				.noteScreen().getSearchButton()));
		// NAF元素需要开发配合修改后才能通过
		Assert.assertTrue("期望新增记事按钮显示为true实际为：" + isAddButtonDisplay,
				isAddButtonDisplay);
		// NAF元素需要开发配合修改后才能通过
		Assert.assertTrue("期望搜索按钮显示为true实际为：" + isSeachButtonDisplay,
				isSeachButtonDisplay);
		List<String> noteList = app.remindNoteScreen().getRemindNoteListDate();

		for (int i = 0; i < noteList.size(); i++) {
			for (int j = i + 1; j < noteList.size(); j++) {

				// boolean firstBigThantwo = false;
				// app.noteScreen();
				int dateOrder = AbstractScreen.compare_date(noteList.get(i),
						noteList.get(j));
				// 判断日期排序正确
				Assert.assertEquals(1, dateOrder);
			}

		}
		// 退出记事页面
		app.remindNoteScreen().getBackButton().click();
		// ((AndroidDriver<?>)driver).pressKeyCode(AndroidKeyCode.BACK);

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	// 步骤：
	// 点击生日、纪念日
	//
	// 期望
	// 跳转到生日、纪念日记事界面，显示搜索和＋按钮，切换分类正常
	//
	// 中间部分显示距离时间且正确
	//
	// 生日记事，纪念日记事内容和排序正确（最先提醒的在最前面）
	@Test
	// @Ignore("NAF元素需要开发配合修改后才能通过")
	public void test4Birthday() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		logger.info("验证生日、纪念日....");
		// Activity ac = new Activity("com.updrv.lifecalendar",
		// ".activity.recordthing.AnniversaryListActivity");

		// ((StartsActivity) driver).startActivity(ac);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		boolean isRemindTagDis = false;
		isRemindTagDis = as.waitElentAndCapture(app.mainScreen().remindPageTag,
				"提醒标签未显示");
		// 后面用反射获取到失败方法的完整名称
		if (isRemindTagDis) {
			app.mainScreen().remindPageTag.click();
		}
		boolean isBirthDisplay = false;
		isBirthDisplay = as.waitElentAndCapture(
				app.remindScreen().birthAnniversaryItem,
				app.remindScreen().birthAnniversaryItem.toString());
		if (isBirthDisplay) {
			app.remindScreen().birthAnniversaryItem.click();
		}

		// 暂时屏蔽 待添加accessibilty信息后再操作
		boolean isSeachButtonDisplay = false;
		boolean isAddButtonDisplay = false;
		isAddButtonDisplay = as.isWidgetDisplay((app
				.birthDayAnniversaryScreen().getAddButton()));

		isSeachButtonDisplay = as.isWidgetDisplay((app
				.birthDayAnniversaryScreen().getSearchButton()));
		// NAF元素需要开发配合修改后才能通过
		Assert.assertTrue("期望搜索按钮显示为true实际为：" + isAddButtonDisplay,
				isAddButtonDisplay);
		// NAF元素需要开发配合修改后才能通过
		Assert.assertTrue("期望搜索按钮显示为true实际为：" + isSeachButtonDisplay,
				isSeachButtonDisplay);
		List<String> noteList = app.birthDayAnniversaryScreen()
				.getcountDayList();
		boolean countDay = false;
		for (int i = 0; i < noteList.size(); i++) {
			for (int j = i + 1; j < noteList.size(); j++) {
				if (noteList.get(i).equals("今")) {
					if (Integer.parseInt(noteList.get(i + 1)) <= Integer
							.parseInt(noteList.get(j))) {

						countDay = true;
					}
				} else {
					if (Integer.parseInt(noteList.get(i)) <= Integer
							.parseInt(noteList.get(j))) {

						countDay = true;
					}
				}

			}

		}
		logger.info("正在验证生日日倒数日排序...");
		Assert.assertEquals("期望倒数天数第一条数值最新为true,实际为：" + countDay, true,
				countDay);
		logger.info("验证生日倒数日排序成功！");

		String statusName = app.birthDayAnniversaryScreen().getTitle()
				.getText();
		// 判断生日纪念日能够正常切换状态
		if (statusName.equals("生日")) {

			app.birthDayAnniversaryScreen().getAnniversaryTab().click();
			statusName = app.birthDayAnniversaryScreen().getTitle().getText();
			logger.info("正在验证生日切换到纪念日标签...");
			Assert.assertEquals("期望完成状态为纪念日，实际为：" + statusName, "纪念日",
					statusName);
			logger.info("验证生日切换到纪念日成功！");
		}

		// 退出记事页面
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	@After
	public void tearDownForNotes() {
		// 每次执行完毕返回到首页
		boolean isHomePageDisyplayed = false;
		isHomePageDisyplayed = as.waitElentAndCapture(
				app.mainScreen().homePageTag, "查找首页失败");
		if (isHomePageDisyplayed) {
			app.mainScreen().homePageTag.click();
		}
	}
}
