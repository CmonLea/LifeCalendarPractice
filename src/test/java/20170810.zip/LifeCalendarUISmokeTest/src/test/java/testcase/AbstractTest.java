package testcase;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.AfterClass;
import org.junit.Before;
import screen.LifeCalendar;
import util.AppiumDriverBuilder;
import io.appium.java_client.AppiumDriver;

public abstract class AbstractTest {
    private static Logger logger =Logger.getLogger(AbstractTest.class);
	public static AppiumDriver<?> driver;
	protected static LifeCalendar app;// 用于管理页面，返回各个测试页面
	static File classpathRoot = new File(System.getProperty("user.dir"));
	static File appDir = new File(classpathRoot.getParentFile(), "app");
	static File appPath = new File(appDir, "LifeCalendar.apk");

	private static String eMail = getCharAccount((int) (3 + Math.random() * 7))
			+ "@" + getCharAccount((int) (1 + Math.random() * 3)) + "."
			+ getCharAccount((int) (1 + Math.random() * 3));// 邮箱
	private static String userName = getCharAccount((int) (6 + Math.random() * 10));// 注册时输入的用户名
	private static String passWord = getCharAccount((int) (6 + Math.random() * 10));// 注册时输入的用户密码

	// private static String okPassWord = null;// 注册时输入的确认密码

	public static String geteMail() {
		return eMail;
	}

	public static void seteMail(String eMail) {
		AbstractTest.eMail = eMail;
	}

	public static String getUserName() {
		return userName;
	}

	public static void setUserName(String userName) {
		AbstractTest.userName = userName;
	}

	public static String getPassWord() {
		return passWord;
	}

	public static void setPassWord(String passWord) {
		AbstractTest.passWord = passWord;
	}

	/**
	 * 此方法用于获取随机数
	 * 
	 * @param length
	 * @return
	 */
	public static String getCharAccount(int length) {
		String account = "";
		Random random = new Random();

		for (int i = 0; i <= length; i++) {
			// 输出字母还是数字
			String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
			// 字符串
			if ("char".equalsIgnoreCase(charOrNum)) {
				// 取得大写字母还是小写字母
				int choice = random.nextInt(2) % 2 == 0 ? 65 : 97;
				account += (char) (choice + random.nextInt(26));

			} else if ("num".equalsIgnoreCase(charOrNum)) { // 数字
				account += String.valueOf(random.nextInt(10));

			}

		}
		return account;
	}
	

	// 建立本地连接
	@Before
	public  void connect() throws MalformedURLException {
		driver = AppiumDriverBuilder.forAndroid()
				.withEndpoint(new URL("http://127.0.0.1:4723/wd/hub"))
				.build("com.updrv.lifecalendar", ".activity.MainActivity");

//		driver = EventFiringWebDriverFactory.getEventFiringWebDriver(driver,
//				new AppiumListener(driver));

		app = new LifeCalendar(driver);

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		PropertyConfigurator.configure("log4j2.properties");
	}

	@AfterClass
	public static void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}

}