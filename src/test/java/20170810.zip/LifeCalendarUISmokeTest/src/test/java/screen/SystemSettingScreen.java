package screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class SystemSettingScreen extends AbstractScreen {

	public SystemSettingScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/rel_personal_account_show")
	AndroidElement mainPagePlugSetting;

	public AndroidElement getMainPagePlugSetting() {
		return mainPagePlugSetting;
	}

}
