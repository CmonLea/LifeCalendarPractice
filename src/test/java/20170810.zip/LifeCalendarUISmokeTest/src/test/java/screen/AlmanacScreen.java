package screen;

import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

public class AlmanacScreen extends AbstractScreen {

	public AlmanacScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	// 阳历日期
	// 设置5s的延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/tv_yangli")
	public AndroidElement yangli;

	// 向右滑动
	// 设置5s的延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/iv_right")
	public AndroidElement right;

	// 向左滑动
	// 设置5s的延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/iv_left")
	public AndroidElement left;

	// 黄历日期
	// 设置5s的延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/tv_l_date")
	public AndroidElement date;

	// 今字图标
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/to_today")
	public AndroidElement todayIcon;

}
