package screen;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PressesKeyCode;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.WithTimeout;

public class HistoryTodayScreen extends AbstractScreen {

	public HistoryTodayScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBys(value = { @FindBy(id = "com.updrv.lifecalendar:id/history_today_item_layout") })
	public List<AndroidElement> historyList;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	// 历史今天列表信息，如：中国“福建土楼”被正式列入《世界遗产名录》
	@FindBys(value = { @FindBy(id = "com.updrv.lifecalendar:id/history_today_item_content") })
	public List<AndroidElement> itemContent;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	// Webview：历史今天详情页内容
	@FindBy(xpath = "/html/body/h3")
	public WebElement title;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(css = "#content")
	public WebElement webContent;

	int historyInfoListLength = itemContent.size();

	public void swipeAndClick() {
		// 获取当前页面显示历史今天信息条数
		// int historyInfoListLength = itemContent.size();
		logger.info("初始页显示的条目为：" + historyInfoListLength + "条");

		for (int i = 0; i < historyInfoListLength; i++) {

			logger.info("i=" + i);
			try {
				itemContent.get(i).click();
			} catch (Exception e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			}

			// app.historyTodayScreen().itemContent.get(0).click();
			List<String> con = new ArrayList<String>();
			Set<String> contexts = driver.getContextHandles();
			for (String context : contexts) {
				con.add(context);
				logger.info(context);

			}

			if (con.contains("WEBVIEW_com.updrv.lifecalendar")) {
				driver.context("WEBVIEW_com.updrv.lifecalendar");
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}

			try {
				String webTitle = title.getText();
				logger.info("历史今天事件标题为：" + "\t\n" + webTitle);

//				String historywebContent = webContent.getText();
//				if (historywebContent != null || historywebContent != "") {
//					logger.info("历史今天内容为：" + "\t\n" + historywebContent);
//				}

				Assert.assertNotNull("历史今天信息标题不为空", webTitle);
			} catch (Exception e) {
				e.printStackTrace();
			}

			// 返回到列表
			((PressesKeyCode) driver).pressKeyCode(AndroidKeyCode.BACK);
			// 切换到native APP

			driver.context("NATIVE_APP");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//			// 第一屏滑动完毕
//			if (i == historyInfoListLength - 1) {
//				break;
//			}
		}

	}

	public void swipeHistoryList() {
		AndroidElement firstElment = historyList.get(0);// 获取历史今天列表第一条数据控件

		AndroidElement lastElement = historyList.get(historyInfoListLength - 1);// 获取历史今天列表中倒数第一个元素
		// 方法1：能够正常滑动
		Point location1 = firstElment.getLocation();// 获取控件左上角的坐标
		Point center1 = firstElment.getCenter();// 获取控件中心的坐标

		Point location2 = lastElement.getLocation();
		Point center2 = lastElement.getCenter();

		TouchAction swipe = new TouchAction(driver)
				.press(lastElement, center1.x, center2.y - location2.y)
				.waitAction(Duration.ofMillis(500))
				.moveTo(firstElment, center1.x, center1.y - location1.y)
				.release();
		logger.info("开始滑动,从：" + center1.x + "," + (center2.y - location2.y)
				+ "滑动到：" + center1.x + "," + (center1.y - location1.y));
		swipe.perform();
		logger.info("滑动成功！");
	}

}
