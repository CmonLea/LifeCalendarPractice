package testcase;

import io.appium.java_client.android.AndroidDriver;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import rule.TestName;
import screen.AbstractScreen;
import testcase.AbstractTest;
import util.ScreenRecorder;

public class MainScreenDisplay_Calendar_Android_1359Test extends
		AbstractTest {
	private Logger logger = Logger
			.getLogger(MainScreenDisplay_Calendar_Android_1359Test.class);
	AbstractScreen as = new AbstractScreen(driver);

	@Rule
	public TestName name = new TestName();

	@Before
	public void setup() {
		// 如果弹升级框就点掉

		boolean isUpdateWindowDisplay = false;
		isUpdateWindowDisplay = as.isWidgetDisplay(app.mainScreen()
				.getUpdateWindow());
		if (isUpdateWindowDisplay) {
			logger.info("检测到有升级框弹出，正在解除障碍！");
			boolean isCancelButtonDisplay = false;
			isCancelButtonDisplay = as.waitElentAndCapture(app.mainScreen()
					.getUpdateCancelbutton(), "等待取消按钮显示");
			if (isCancelButtonDisplay) {
				app.mainScreen().getUpdateCancelbutton().click();
				logger.info("KO升级框！Perfect！");
			}

		} else {
			logger.info("没有显示升级框！");
		}
	}

	@Test
	public void testMainScreenDisplay() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}

		// 验证主界面黄历控件是否显示
		// app.mainScreen().swipeWidget2Up(app.mainScreen().calendarScreen,
		// "日历控件", 500);
		// 滑动日历控件
		boolean isCalendarDispaly = false;
		isCalendarDispaly = as.waitElentAndCapture(
				app.mainScreen().calendarScreen,
				app.mainScreen().calendarScreen.toString());
		if (isCalendarDispaly) {

			as.swipeWidget2Up((AndroidDriver<?>) driver,
					app.mainScreen().calendarScreen, 500);
		}
		boolean isAlmnacDisplay = app.mainScreen().almanacWidget.isDisplayed();
		Assert.assertTrue("期望黄历显示为true，实际为" + isAlmnacDisplay, isAlmnacDisplay);

		// 验证主界面天气插件是否显示
		// app.mainScreen().swipeWidget2Up(app.mainScreen().almanacWidget,
		// "黄历控件",
		// 500);
		// 滑动黄历
		as.swipeWidget2Up((AndroidDriver<?>) driver,
				app.mainScreen().almanacWidget, 0);

		// app.mainScreen().swipeWidget2Up(app.mainScreen().advertisement,
		// "广告控件",
		// 500);
		boolean isadvertisementDisplay = false;
		isadvertisementDisplay = as.waitElentAndCapture(
				app.mainScreen().weatherWidget,
				app.mainScreen().weatherWidget.toString());
		if (isadvertisementDisplay) {
			as.swipeWidget2Up((AndroidDriver<?>) driver,
					app.mainScreen().advertisement, 0);
		}
		boolean isWeatherDisplay = false;
		isWeatherDisplay = app.mainScreen().weatherWidget.isDisplayed();
		Assert.assertTrue("期望天气显示为true，实际为" + isWeatherDisplay,
				isWeatherDisplay);

		if (isWeatherDisplay) {
			as.swipeWidget2Up((AndroidDriver<?>) driver,
					app.mainScreen().weatherWidget, 0);
		}
		// 验证主界面星座插件是否显示
		boolean ishoroscopeDisplay = false;
		ishoroscopeDisplay = as.waitElentAndCapture(
				app.mainScreen().horoscopeWidget,
				app.mainScreen().horoscopeWidget.toString());
		// 滑动星座
		if (ishoroscopeDisplay) {
			as.swipeWidget2Up((AndroidDriver<?>) driver,
					app.mainScreen().horoscopeWidget, 0);
		}

		// app.mainScreen().swipeWidget2Up(app.mainScreen().weatherWidget,
		// "天气控件",
		// 500);

		Assert.assertTrue("期望星座显示为true，实际为" + ishoroscopeDisplay,
				ishoroscopeDisplay);

		// 验证主界面历史今天插件是否显示

		// app.mainScreen().swipeWidget2Up(app.mainScreen().horoscopeWidget,
		// "星座控件", 500);
		// 滑动星座
		// as.swipeWidget2Up((AndroidDriver<?>) driver,
		// app.mainScreen().horoscopeWidget, 500);
		boolean isRemindDisplay = false;
		isRemindDisplay = as.waitElentAndCapture(
				app.mainScreen().vertical_main,
				app.mainScreen().vertical_main.toString());
		if (isRemindDisplay) {
			app.mainScreen().swipeFullRemind2Up();
		}


		boolean isHistoryDisplay = false;
		try {

			isHistoryDisplay = app.mainScreen().historyWidget.isDisplayed();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		if (isHistoryDisplay) {
			Assert.assertTrue("期望历史今天显示为true，实际为" + isHistoryDisplay,
					isHistoryDisplay);
		}

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {

			e.printStackTrace();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

}
