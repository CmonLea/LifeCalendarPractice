package testcase;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import util.FavFTPUtil;
/**
 * 测试APK安装
 * @author test
 *
 */
@Ignore
public class ApkInstall_Calendar_Android_775Test {
	// AppiumDriver<WebElement> driver;
	public static Logger logger = Logger
			.getLogger(ApkInstall_Calendar_Android_775Test.class);
	AppiumDriver<WebElement> driver;
	File classpathRoot = new File(System.getProperty("user.dir"));
	File appDir = new File(classpathRoot, "app");
	File app = new File(appDir, "rili_CHESHI.apk");
	private static String hostname = "192.168.100.160";
	private static int port = 21;
	private static String username = "write";
	private static String password = "updrv.com";
	private static String pathname = "/各项目测试包/手机日历-Android/";
	private static String filename = "rili_CHESHI.apk";
	private static File file = new File("app");

	private static String localpath = "app/";

	@BeforeClass
	public static void downLoadApp() {
		if (!file.exists()) {
			file.mkdirs();
		}
		FavFTPUtil.downloadFile(hostname, port, username, password, pathname,
				filename, localpath);
	}

	@Before
	public void setUp() {
		// System.out.println(app.getAbsolutePath());
		PropertyConfigurator.configure("log4j2.properties");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", "Coolpad8670");
		capabilities.setCapability("platformVersion", "4.4");
		capabilities.setCapability("app", app.getAbsolutePath());
		capabilities.setCapability("unicodeKeyboard", true);
		capabilities.setCapability("resetKeyboard", true);
		capabilities.setCapability("newCommandTimeout", 120);
		// capabilities.setCapability("noReset","false");
		// capabilities.setCapability("fullReset","true");
		try {
			driver = new AndroidDriver<>(
					new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		} catch (MalformedURLException e) {

			e.printStackTrace();
		}

	}

	@Test
	public void installApk() {
		boolean isAppInstalled = driver
				.isAppInstalled("com.updrv.lifecalendar");

		if (isAppInstalled) {
			logger.info("手机上存在旧版本应用正在卸载应用...");
			driver.removeApp("com.updrv.lifecalendar");
			logger.info("重新安装应用...");
			driver.installApp(app.getAbsolutePath());
			if (!isAppInstalled) {
				logger.info("应用安装失败");
				Assert.assertFalse(!isAppInstalled);
			} else {
				logger.info("应用安装成功");

				Assert.assertTrue(isAppInstalled);
				driver.launchApp();

				Activity activity = new Activity("com.updrv.lifecalendar",
						".activity.GuideActivity");

			}

		} else {
			logger.info("手机上不存在旧版本应用，直接安装应用...");
			driver.installApp(app.getAbsolutePath());
			if (!isAppInstalled) {
				logger.info("应用安装失败");
				Assert.assertFalse(!isAppInstalled);
			} else {
				logger.info("应用安装成功");
				Assert.assertTrue(isAppInstalled);
			}

		}
	}

	@After
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}
}
