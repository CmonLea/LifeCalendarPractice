package screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.WithTimeout;

public class RegisterScreen extends AbstractScreen {

	public RegisterScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/user_name")
	public WebElement userName;
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/email")
	public WebElement eMail;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/user_pwd")
	public WebElement passWord;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/user_pwd_ok")
	public WebElement okPassWord;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/btn_register")
	public WebElement registerBtn;

	public void register(String userName, String eMail, String password,
			String okPassword) {
		try {
			this.userName.sendKeys(userName);
			this.eMail.sendKeys(eMail);
			this.passWord.sendKeys(password);
			this.okPassWord.sendKeys(okPassword);
			this.registerBtn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
