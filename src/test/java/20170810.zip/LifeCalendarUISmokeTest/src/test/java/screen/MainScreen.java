package screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.SwipeElementDirection;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

@SuppressWarnings("deprecation")
public class MainScreen extends AbstractScreen {

	public MainScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(name = "首页")
	// 首页按钮
	public WebElement homePageTag;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(name = "提醒")
	// 提醒按钮
	public WebElement remindPageTag;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(name = "发现")
	// 发现按钮
	public static WebElement foundPageTag;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/lin_menu_main_personal_account")
	// 我的按钮
	public WebElement myPageTag;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/almanac_main")
	// 黄历插件id
	public AndroidElement almanacWidget;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/layout_home")
	// 广告插件
	public AndroidElement advertisement;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/iv_weather_container_ll")
	// 天气插件id
	public AndroidElement weatherWidget;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/calender_constellation_layout")
	// 星座插件id
	public AndroidElement horoscopeWidget;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/main_dp")
	// 日历界面区域id
	public AndroidElement calendarScreen;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/vertical_main")
	// 公众提醒区域id
	public AndroidElement vertical_main;

	// @AndroidFindBy(id = "com.updrv.lifecalendar:id/layout_root")
	// // 公众提醒区域id
	// AndroidElement singleRemind;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/history_today_layout")
	// 历史今天布局控件id
	public AndroidElement historyWidget;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/dialog_text")
	// 主界面升级框id
	private AndroidElement updateWindow;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/dialog_text3")
	// 主界面升级框取消按钮id
	private AndroidElement updateCancelbutton;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "android:id/content")
	// 主界面升级框确认控件id
	private AndroidElement updateConfirmButton;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/tv_position_cityName")
	// 主界面天气插件显示的城市的id
	private AndroidElement weatherPlugCityName;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/constellationName")
	// 主界面星座插件显示的星座日期的id
	private AndroidElement mainScrennScopeName;
	
	
	public AndroidElement getMainScrennScopeName() {
		return mainScrennScopeName;
	}

	//返回主页天气插件中显示的城市名称
	public AndroidElement getWeatherPlugCityName() {
		return weatherPlugCityName;
	}

	// 升级框弹出返回取消按钮控件
	public AndroidElement getUpdateCancelbutton() {
		return updateCancelbutton;
	}

	// 升级框弹出时返回确认按钮控件
	public AndroidElement getUpdateConfirmButton() {
		return updateConfirmButton;
	}

	// 升级框弹出时，返回升级框控件按钮
	public AndroidElement getUpdateWindow() {
		return updateWindow;
	}

	@Override
	public boolean isWidgetDisplay(AndroidElement androidElement) {
		boolean isWidgetDisplay = false;

		// isWidgetDisplay = waitElentAndCapture(androidElement,
		// "查找"+androidElement.toString()+"控件失败");
		try {
			isWidgetDisplay = androidElement.isDisplayed();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (isWidgetDisplay) {
			return true;
		}

		else {
			return false;
		}

	}

	public void clickHomePageTag() {
		try {
			if (homePageTag.isDisplayed()) {
				homePageTag.click();
			} else {
				logger.error("首页标签控件查找失败");
				waitElentAndCapture(homePageTag, "首页标签控件查找失败");
			}
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	public void clickRemindPageTag() {

		try {
			if (remindPageTag.isDisplayed()) {
				remindPageTag.click();
			} else {
				logger.error("提醒标签控件查找失败");
				waitElentAndCapture(remindPageTag, "提醒标签控件查找失败");
			}
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	public void clickFoundPageTag() {
		// PropertyConfigurator.configure("log4j2.properties");
		if (foundPageTag.isDisplayed()) {
			foundPageTag.click();
		} else {
			logger.error("提醒标签控件查找失败");
			waitElentAndCapture(foundPageTag, "发现标签查找失败");
		}

	}

	public void clickMyPageTag() {

		try {
			if (myPageTag.isDisplayed()) {
				myPageTag.click();
			} else {
				logger.error("我的标签控件查找失败");
				waitElentAndCapture(myPageTag, "我的标签控件查找失败");
			}
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	@SuppressWarnings("deprecation")
	public void swipeFullRemind2Up() {
		logger.info("滑动公众提醒...");
		vertical_main.getLocation();
		int y1 = vertical_main.getLocation().y;
		// Point p1 = new Point(x1, y1);
		int x2 = vertical_main.getSize().width;
		// logger.info("vertical_main.getSize()="+vertical_main.getSize());
		int y2 = vertical_main.getSize().height;
		logger.info("滑动x轴起点x2:" + x2 / 2);
		logger.info("滑动y轴起点y2:" + y2);
		logger.info("滑动y轴终点y1:" + y1);
		// logger.info("y2-y1"+(y2-y1));
		boolean isRemindDisplay = false;
		try {
			isRemindDisplay = vertical_main.isDisplayed();
		} catch (Exception e) {

			e.printStackTrace();
		}
		if (isRemindDisplay) {
			// 向上滑动公众提醒
			logger.info("向上滑动公众提醒...");
			// vertical_main.swipe(direction.UP, 500);
			// for(int i=0;i<5;i++){
			logger.info("y2*1/4..." + y2 * 1 / 4);
			// direction.swipe(driver, vertical_main, x2/4, y2/4, 500);
			driver.swipe(x2 / 2, y2 * 1 / 2, x2 / 2, y1, 500);
			driver.swipe(x2 / 2, y2 * 1 / 2, x2 / 2, y1, 500);
			// }

			logger.info("向上滑动公众提醒完毕,请查看是否有位移偏移...");
		} else {
			// 查找并等待失败则截图
			boolean wait = waitElentAndCapture(vertical_main, "查找公众提醒失败");
			if (wait) {
				driver.swipe(x2 / 2, y2 * 2 / 3, x2 / 2, y1, 500);
				logger.info("滑动公众提醒插件完毕...");
			}

		}

	}

	// 当进入日历主界面没有显示相应的插件时不关联的用例直接忽略相应插件执行此方法
	public void swipeAllNotDisyPlayWidget() {

	}

//	/**
//	 * 
//	 * @param androidWidgit
//	 *            Android控件
//	 * @param widgetName
//	 *            控件名称
//	 */
//	@Override
//	public void swipeWidget2Up(AndroidElement androidWidgit, String widgetName,
//			int duration) {
//		logger.info("滑动日历" + widgetName + "...");
//		boolean isWidgetDisplay = false;
//		// try {
//		// isWidgetDisplay = androidWidgit.isDisplayed();
//		// } catch (Exception e) {
//		//
//		// e.printStackTrace();
//		// }
//		isWidgetDisplay = isWidgetDisplay(androidWidgit);
//		if (isWidgetDisplay) {
//			androidWidgit.swipe(SwipeElementDirection.UP, duration);
//			logger.info("日历主界面插件" + widgetName + "滑动完毕...");
//		} else {
//			boolean wait = waitElentAndCapture(androidWidgit, "查找日历控件"
//					+ widgetName + "失败");
//			if (wait) {
//				androidWidgit.swipe(SwipeElementDirection.UP, duration);
//				logger.info("日历主界面插件" + widgetName + "滑动完毕...");
//			} else {
//				// Throwable NoSuchElementException = null;
//				logger.error("没有查找到" + widgetName);
//			}
//
//		}
//
//	}

	// 滑动日历、黄历、广告、天气、星座方法
	// @SuppressWarnings("deprecation")
	// public void swipeCommonWidget2Up() {
	// logger.info("滑动星座插件...");
	// boolean isHoroscopeDisplay = false;
	// try {
	// isHoroscopeDisplay = horoscopeWidget.isDisplayed();
	// } catch (Exception e) {
	//
	// e.printStackTrace();
	// }
	// if (isHoroscopeDisplay) {
	// // 向上滑动星座
	// horoscopeWidget.swipe(SwipeElementDirection.UP, 500);
	// logger.info("滑动星座插件完毕...");
	// } else {
	// // 查找并等待失败则截图
	// boolean wait = waitElentAndCapture(horoscopeWidget, "查找星座失败");
	// if (wait) {
	// horoscopeWidget.swipe(SwipeElementDirection.UP, 500);
	// logger.info("滑动星座插件完毕...");
	// }
	//
	// }
	//
	// }

}
