package util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class ScreenRecorder {
	private static Logger logger = Logger.getLogger(ScreenRecorder.class);

	private static List<String> ADBProcessIDsBeforeScreenRecording = null;
	private static List<String> ADBProcessIDsAfterScreenRecording = null;
	private static File recordFolder = new File("ScreenRecording");

	public static void StartScreenRecording(String CurrentTestMethodName)
			throws IOException {
		logger.info("开始录制视频...");
		// 录制前获取所有的adb进程
		ADBProcessIDsBeforeScreenRecording = getProcessIDs("adb.exe");

		// 开始和当前的方法录制
		Runtime.getRuntime().exec(
				"cmd /c adb shell screenrecord --size 1280x720 --bit-rate 1000000 //sdcard//"
						+ CurrentTestMethodName + ".mp4");

	}

	public static void StopScreenRecording(String CurrentTestMethodName,

	String DirectoryToSaveRecordedScreen, boolean RemoveRecordedScreenFromDevice)
			throws IOException, InterruptedException {
		if (!recordFolder.exists()) {
			recordFolder.mkdirs();
		}
		DirectoryToSaveRecordedScreen = recordFolder.getAbsolutePath();
		// 获取录制后的adb进程
		ADBProcessIDsAfterScreenRecording = getProcessIDs("adb.exe");

		// 杀掉录制的adb进程
		for (String id : ADBProcessIDsAfterScreenRecording) {
			boolean found = false;
			for (String tgtid : ADBProcessIDsBeforeScreenRecording) {
				if (tgtid.equals(id)) {
					found = true;
					break;
				}
			}
			if (!found) {
				Runtime.getRuntime().exec("taskkill /F /PID " + id);
				break;
			}
		}

		// 休眠2s种来存储视频
		Thread.sleep(2000);

		// 将手机中的视频pull到PC
		logger.info("正在拷贝视频:" + CurrentTestMethodName + ".mp4 " + "到"
				+ DirectoryToSaveRecordedScreen);
		//防止带空格的路径拷贝失败
		Runtime.getRuntime().exec(
				"cmd /c adb pull //sdcard//" + CurrentTestMethodName + ".mp4 "
						+ "\""+DirectoryToSaveRecordedScreen+"\"");

		// 等待5s完成手机中视频到PC端的拷贝
		Thread.sleep(5000);

		if (RemoveRecordedScreenFromDevice) {
			// 删除设备中的视频
			logger.info("正在删除手机中的视频...");
			Runtime.getRuntime().exec(
					"cmd /c adb shell rm //sdcard//" + CurrentTestMethodName
							+ ".mp4");
		}

	}

	/**
	 * 用来获取所有运行进程名称
	 * 
	 * @param processName
	 * @return
	 */
	static List<String> getProcessIDs(String processName) {
		List<String> processIDs = new ArrayList<String>();
		try {
			String line;
			// 执行cmd获取进程id
			Process p = Runtime.getRuntime().exec("tasklist /v /fo csv");
			BufferedReader input = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			while ((line = input.readLine()) != null) {
				if (!line.trim().equals("")) {
					// 例如："taskeng.exe","3916"
					// 进程名称名称在第一个分隔符后
					String currentProcessName = line.split("\"")[1];
					// pid在第3个分隔符后
					String currentPID = line.split("\"")[3];
					if (currentProcessName.equalsIgnoreCase(processName)) {
						processIDs.add(currentPID);
					}
				}
			}
			if (input != null) {
				input.close();
			}

		} catch (Exception err) {
			err.printStackTrace();
		}
		return processIDs;
	}

}