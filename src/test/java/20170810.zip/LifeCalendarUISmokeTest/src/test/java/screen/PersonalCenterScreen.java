package screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class PersonalCenterScreen extends AbstractScreen {

	public PersonalCenterScreen(AppiumDriver<?> driver) {
		super(driver);
		// TODO 自动生成的构造函数存根
	}

	// @FindAll(id ="com.updrv.lifecalendar:id/user_center_etit_text")
	// @FindBys({@FindBy(id ="com.updrv.lifecalendar:id/user_center_etit_text"),
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/user_center_etit_text")
	// 退出登录按钮控件id
	WebElement logoutButton;

	// 用户记事条数
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/user_all_message")
	private AndroidElement cloudsData;

	// })

	public AndroidElement getCloudsData() {
		return cloudsData;
	}

	public void logOut() {
		try {
			if (isElementDisplayed(logoutButton)) {
				logoutButton.click();

			} else {
				waitElentAndCapture(logoutButton, "退出登录控件未找到");

			}
			driver.findElementByName("确定").click();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}
