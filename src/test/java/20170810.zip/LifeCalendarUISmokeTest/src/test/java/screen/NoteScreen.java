package screen;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class NoteScreen extends AbstractScreen {

	public NoteScreen(AppiumDriver<?> driver) {
		super(driver);
		// TODO 自动生成的构造函数存根
	}

	// String str = "2018年12月(10)";
	// 正则表达式匹配类似"2018年12月(10)"的字符串括号往前的内容及2018年12月
	Pattern regex = Pattern.compile("\\(\\d{1,5}\\)");
	// 日历记事搜索控件id(普通记事、提醒)
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/rl_note_to_search")
	WebElement searchButton;

	//待办搜索按钮：com.updrv.lifecalendar:id/iv_search
	
	/*
	 * 搜索控件相关控件
	 */
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/ll_note_back")
	AndroidElement noteBackButton;

	public AndroidElement getNoteBackButton() {
		return noteBackButton;
	}

	// 普通记事页面搜索框
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/et_record_search")
	private AndroidElement searchText;

	public AndroidElement getSearchText() {
		return searchText;
	}

	// 普通记事搜索框上的搜索按钮
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/btn_record_search")
	private AndroidElement searchTextButton;

	public AndroidElement getSearchTextButton() {
		return searchTextButton;
	}

	// 普通记事搜索框上的取消按钮
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/btn_record_search_cancle")
	private AndroidElement searchCancelButton;

	public AndroidElement getSearchCancelButton() {
		return searchCancelButton;
	}

	// 普通记事搜索结果显示区域id
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/listview")
	private AndroidElement searchResultArea;

	public AndroidElement getSearchResultArea() {
		return searchResultArea;
	}

	// 日历新增记事控件id
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/rl_note_to_add")
	WebElement newButton;

	// 日历记事条目上的日期，如：2018年12月(10)
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/one_status_name")
	List<WebElement> recordName;

	// 记事列表显示的记事内容
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/ll_content")
	private List<AndroidElement> notesContent;

	// 长按记事弹出的删除框界面删除按钮id
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/ll_pop_list_edit_to_del")
	private AndroidElement noteDeleteButton;

	/*
	 * 
	 * 删除记事弹框相关按钮
	 */

	// 删除提示窗口android:id/content
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "android:id/content")
	private AndroidElement deleteConfirmWindow;

	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/dialog_text2")
	private AndroidElement deleteConfimButton;

	public AndroidElement getDeleteConfimButton() {
		return deleteConfimButton;
	}

	public AndroidElement getDeleteCancelButton() {
		return deleteCancelButton;
	}
//设置5s延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/dialog_text2")
	private AndroidElement deleteCancelButton;

	public AndroidElement getDeleteConfirmWindow() {
		return deleteConfirmWindow;
	}

	public AndroidElement getNoteDeleteButton() {
		return noteDeleteButton;
	}

	public List<AndroidElement> getNotesContent() {
		return notesContent;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	public WebElement getNewButton() {
		return newButton;
	}

	public List<WebElement> getRecordName() {
		return recordName;
	}

	public List<String> getNoteListDate() {
		// Iterator<WebElement> it = recordName.iterator();
		List<String> noteDates = new ArrayList<String>();
		// System.out.println(recordName.size());
		for (int i = 0; i < recordName.size(); i++) {
			// 输出匹配后的年月日
			logger.info(recordName.get(i).getText().split(regex.toString())[0]);
			noteDates
					.add(recordName.get(i).getText().split(regex.toString())[0]);

		}

		return noteDates;
	}

	public static int compare_date(String DATE1, String DATE2) {

		DateFormat df = new SimpleDateFormat("yyyy年mm月");
		DateFormat remindDf = new SimpleDateFormat("yyyy-mm-dd hh : mm");
		try {
			Date dt1 = df.parse(DATE1);
			Date dt2 = df.parse(DATE2);
			if (dt1.getTime() > dt2.getTime()) {
				// logger.info("dt1:" + dt1.getTime() + "在dt2:"
				// + dt2.getTime() + "后");
				logger.info("dt1:" + DATE1 + "在dt2:" + DATE2 + "后");
				return 1;
			} else if (dt1.getTime() < dt2.getTime()) {
				// logger.info("dt1:" + dt1.getTime() + "在dt2:"
				// + dt2.getTime() + "前");
				logger.info("dt1:" + DATE1 + "在dt2:" + DATE2 + "前");
				return -1;
			} else {
				return 0;
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return 0;
	}
}
