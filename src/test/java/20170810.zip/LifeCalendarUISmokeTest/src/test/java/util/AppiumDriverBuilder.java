package util;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

public abstract class AppiumDriverBuilder<SELF, DRIVER extends AppiumDriver<?>> {
	
	protected URL endpoint;

	@SuppressWarnings("unchecked")
	public SELF withEndpoint(URL endpoint) {
		this.endpoint = endpoint;

		return (SELF) this;
	}

	// public abstract DRIVER build();

	public static AndroidDriverBuilder forAndroid() {
		return new AndroidDriverBuilder();
	}

	public static class AndroidDriverBuilder extends
			AppiumDriverBuilder<AndroidDriverBuilder, AndroidDriver<?>> {

		DesiredCapabilities capabilities = new DesiredCapabilities();

		// 返回带capability参数的 endpoint
		//@SuppressWarnings("rawtypes")
		public AndroidDriver<?> build(String appPackage,String appActivity) {

			capabilities.setCapability("platformName", "Android");
			//capabilities.setCapability("deviceName", "testDevice");
			
			//使用Android模拟器
			capabilities.setCapability("deviceName", "samsung");
			//使用Android模拟器
			capabilities.setCapability("platformVersion", "4.4");
			capabilities.setCapability("appWaitActivity", ".activity.MainActivity");
			//设置等待首页启动的时间为60s
			capabilities.setCapability("appWaitDuration", "90000");
			capabilities.setCapability("newCommandTimeout", 120);
			//capabilities.setCapability("platformVersion", "4.4.2");
			capabilities.setCapability("noReset",true);
//			capabilities.setCapability("appPackage", "com.updrv.lifecalendar");
//			capabilities.setCapability("appActivity", ".activity.MainActivity");
			
			capabilities.setCapability("appPackage", appPackage);
			capabilities.setCapability("appActivity", appActivity);
			
			capabilities.setCapability("unicodeKeyboard", true);
			capabilities.setCapability("resetKeyboard", true);
			capabilities.setCapability("deviceReadyTimeout",60);

			return new AndroidDriver(endpoint, capabilities);

		}

	}

}
