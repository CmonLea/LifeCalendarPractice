package screen;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class BirthDayAnniversaryScreen extends AbstractScreen {

	public BirthDayAnniversaryScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	// 纪念日生日页面搜索按钮
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/iv_search")
	private AndroidElement searchButton;

	// 纪念日生日页面添加按钮
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/iv_add")
	private AndroidElement addButton;

	// 纪念日生日页面倒计时框
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(xpath = "//android.widget.ListView/android.widget.RelativeLayout")
	private AndroidElement countdownDay;

	// 纪念日生日页面倒数日数字
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(xpath = "/android.widget.LinearLayout[@id='com.updrv.lifecalendar:id/layout_day']/android.widget.TextView")
	private List<AndroidElement> countdownDayNumber;

	// 纪念日生日页面倒数日数字
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/tv_gap_age")
	private List<AndroidElement> countdownDayNumberList;

	// 纪念日生日页面标题
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/tv_title_name")
	private AndroidElement title;

	// 纪念日生日页面生日tab
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/layout_left")
	private AndroidElement birthdayTab;

	public AndroidElement getBirthdayTab() {
		return birthdayTab;
	}

	public AndroidElement getAnniversaryTab() {
		return anniversaryTab;
	}

	// 纪念日生日页面纪念日tab
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/layout_right")
	private AndroidElement anniversaryTab;

	public AndroidElement getTitle() {
		return title;
	}

	public AndroidElement getSearchButton() {
		return searchButton;
	}

	public AndroidElement getAddButton() {
		return addButton;
	}

	public AndroidElement getCountdownDay() {
		return countdownDay;
	}

	public List<AndroidElement> getCountdownDayNumber() {
		return countdownDayNumber;
	}

	public List<AndroidElement> getCountdownDayNumberList() {
		return countdownDayNumberList;
	}

	/**
	 * 用来获取生日列表的倒数天数列表
	 * 
	 * @return
	 */
	public List<String> getcountDayList() {
		List<String> dayList = new ArrayList<String>();
		String regex = "天";
		for (int i = 0; i < countdownDayNumberList.size(); i++) {
			logger.info("获取前几条倒数日：" + countdownDayNumberList.get(i).getText());
			dayList.add(countdownDayNumberList.get(i).getText().split(regex)[0]);

		}

		return dayList;

	}

	/**
	 * 此方法用来获取页面展示也显示的倒数天数
	 * 
	 * @return
	 */
	public void getBannerDayCount() {
		String str = null;
		// for(AndroidElement an:countdownDayNumber){
		// str =an.getText();
		// logger.info("============"+str);
		// }
		for (int i = 0; i < countdownDayNumber.size(); i++) {
			logger.info("================" +countdownDayNumber.size());
			str = countdownDayNumber.get(i).getText();
			logger.info("================" + str);
		}
		logger.info("================" +countdownDayNumber.size());
		logger.info("================" + str);

		// return dayCount;

	}

}
