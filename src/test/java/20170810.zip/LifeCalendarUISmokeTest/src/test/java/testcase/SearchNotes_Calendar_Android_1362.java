package testcase;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import rule.TestName;
import screen.AbstractScreen;
import util.ScreenRecorder;

@RunWith(Parameterized.class)
public class SearchNotes_Calendar_Android_1362 extends AbstractTest {
	private Logger logger = Logger
			.getLogger(SearchNotes_Calendar_Android_1362.class);
	AbstractScreen as = new AbstractScreen(driver);
	@Rule
	public TestName name = new TestName();

	@Before
	public void readyData() {
		boolean isMyPageTagDisyplay = false;
		isMyPageTagDisyplay = as.waitElentAndCapture(
				app.mainScreen().myPageTag, "主界面我的");
		if (isMyPageTagDisyplay) {
			app.mainScreen().myPageTag.click();
		}

		if (app.myScreen().isLogin()) {
			app.myScreen().enterLogOutPage();// 进入退出登录页面
			app.personalCenterScreen().logOut();// 退出登录
		}

		app.mainScreen().myPageTag.click();

		app.myScreen().enterLoginPage();

		app.loginScreen().login("apple04", "123456");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e2) {
			// TODO 自动生成的 catch 块
			e2.printStackTrace();
		}
	}

	// 步骤：进入任意类型记事列表，点击搜索按钮，输入正确的搜索内容

	// 结果： 搜索框显示显示出所有符合搜索条件的所有记事，且记事类型，标题和时间显示正确

	/**
	 * @param fInput
	 * @param fExpected
	 */
	public SearchNotes_Calendar_Android_1362(String fInputType,
			String searchText, boolean fExpected) {
		super();
		this.fInputType = fInputType;
		this.searcheText = searchText;
		this.fExpected = fExpected;

	}

	@Parameters
	public static Collection<Object[]> data() {
		return Arrays.asList(new Object[][] { { "普通记事", "2016", true },
				{ "提醒", "18", true }, { "待办日程", "待办记事", true },
				{ "生日纪念日", "回来了", true } });
	}

	private String fInputType;
	private String searcheText;
	private boolean fExpected;

	@Test
	public void testSearchNotes() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}

		boolean isRemindPageTagDisplay = false;
		isRemindPageTagDisplay = as.waitElentAndCapture(
				app.mainScreen().remindPageTag, "提醒标签未显示");
		if (isRemindPageTagDisplay) {
			app.mainScreen().remindPageTag.click();
		}

		AndroidElement searchButton = null;
		switch (fInputType) {
		case "普通记事":
			boolean isNoteItemDis = false;
			isNoteItemDis = as.waitElentAndCapture(app.remindScreen().noteItem,
					"记事标签未显示");
			if (isNoteItemDis) {
				app.remindScreen().noteItem.click();
				searchButton = (AndroidElement) app.noteScreen()
						.getSearchButton();
			}

			break;

		case "提醒":
			boolean isremindItem = false;
			isremindItem = as.waitElentAndCapture(
					app.remindScreen().remindItem, "提醒标签未显示");
			if (isremindItem) {
				app.remindScreen().remindItem.click();
				searchButton = (AndroidElement) app.noteScreen()
						.getSearchButton();
			}

			break;
		case "待办日程":

			boolean isBacklogDis = false;
			isBacklogDis = as.waitElentAndCapture(
					app.remindScreen().backlogScheduleItem, "待办日程标签未显示");
			if (isBacklogDis) {
				app.remindScreen().backlogScheduleItem.click();
				searchButton = app.birthDayAnniversaryScreen()
						.getSearchButton();
			}

			break;
		case "生日纪念日":
			boolean isBirthDis = false;
			isBirthDis = as.waitElentAndCapture(
					app.remindScreen().birthAnniversaryItem, "生日纪念未显示");
			if (isBirthDis) {
				app.remindScreen().birthAnniversaryItem.click();
				searchButton = app.birthDayAnniversaryScreen()
						.getSearchButton();
			}

			break;
		}
		// 启动搜索按钮
		searchButton.click();
		// 输入搜索文本
		app.noteScreen().getSearchText().sendKeys(searcheText);
		// 执行搜索
		app.noteScreen().getSearchTextButton().click();
		AndroidElement searchArea = app.noteScreen().getSearchResultArea();
		boolean isNotesDisplay = false;

		isNotesDisplay = app.noteScreen().isWidgetDisplay(searchArea);
		logger.info("正在验证" + fInputType + "搜索是否成功...");
		if (!isNotesDisplay) {
			logger.info("验证" + fInputType + "搜索完毕...");
		}
		// 验证返回结果
		Assert.assertEquals("期望搜索结果为true", fExpected, isNotesDisplay);
		// 返回到主界面
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	@After
	public void tearDownSearch() {
		boolean isMyPageTagDisyplay = false;
		isMyPageTagDisyplay = as.waitElentAndCapture(
				app.mainScreen().myPageTag, "主界面我的");
		if (isMyPageTagDisyplay) {
			app.mainScreen().myPageTag.click();
		}
		if (app.myScreen().isLogin()) {
			app.myScreen().enterLogOutPage();// 进入退出登录页面
			app.personalCenterScreen().logOut();// 退出登录
		}
	}

}
