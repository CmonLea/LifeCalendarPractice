package screen;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

public class ScheduleScreen extends AbstractScreen {

	public ScheduleScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	// 待办控件ID
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/layout_left")
	private AndroidElement readDo;

	// 日程控件id
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/layout_right")
	private AndroidElement schedule;

	// 待办页面勾选按钮id
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/ll_check")
	private AndroidElement readDoChekButton;

	// 待办完成状态id
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/one_status_name")
	private AndroidElement statusName;

	// 待办列表
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/swipe")
	private List<AndroidElement> readyList;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/iv_back")
	private AndroidElement backButton;

	public AndroidElement getBackButton() {
		return backButton;
	}

	public List<AndroidElement> getReadyList() {
		return readyList;
	}

	public AndroidElement getStatusName() {
		return statusName;
	}

	public AndroidElement getReadDo() {
		return readDo;
	}

	public AndroidElement getSchedule() {
		return schedule;
	}

	public AndroidElement getReadDoChekButton() {
		return readDoChekButton;
	}

}
