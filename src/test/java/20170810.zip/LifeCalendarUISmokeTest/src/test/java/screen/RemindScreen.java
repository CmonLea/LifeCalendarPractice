package screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.WithTimeout;

public class RemindScreen extends AbstractScreen {

	public RemindScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	// 主界面"提醒"页面，普通记事条目
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/item_view_recover_note")
	public WebElement noteItem;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	// 主界面"提醒"页面，待办-日程条目
	@FindBy(id = "com.updrv.lifecalendar:id/item_view_recover_schedule")
	public WebElement backlogScheduleItem;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	// 主界面"提醒"页面，提醒条目
	@FindBy(id = "com.updrv.lifecalendar:id/item_view_recover_remind")
	public WebElement remindItem;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	// 主界面"提醒"页面，生日-纪念日条目
	@FindBy(id = "com.updrv.lifecalendar:id/item_view_recover_anniversary")
	public WebElement birthAnniversaryItem;

}
