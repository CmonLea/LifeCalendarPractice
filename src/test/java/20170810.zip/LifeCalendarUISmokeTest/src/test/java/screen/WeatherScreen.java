package screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class WeatherScreen extends AbstractScreen {

	public WeatherScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	public AndroidElement getMainWeatherArea() {
		return mainWeatherArea;
	}

	public AndroidElement getWeather7Area() {
		return weather7Area;
	}

	public AndroidElement getWeather24Area() {
		return weather24Area;
	}

	public AndroidElement getWeatherAQIArea() {
		return weatherAQIArea;
	}

	public AndroidElement getWeatherLifeArea() {
		return weatherLifeArea;
	}

	public AndroidElement getCityAddButton() {
		return cityAddButton;
	}

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/weather_new_title_iv")
	// 城市显示主区域(添加城市按钮)
	private AndroidElement cityAddButton;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/weather_main_head_view")
	// 天气显示主区域
	AndroidElement mainWeatherArea;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/item_weather_7days_detail_chart")
	// 7天天气显示区域
	AndroidElement weather7Area;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/item_weather_24hours_chart")
	// 24小时天气显示区域
	AndroidElement weather24Area;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/item_weather_aqi_chart")
	// 空气显示区域
	AndroidElement weatherAQIArea;
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/weather_item_life")
	// 生活显示区域
	AndroidElement weatherLifeArea;

	@Override
	public boolean isElementDisplayed(WebElement we) {

		return super.isElementDisplayed(we);
	}

}
