package testsuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import testcase.AboutUsCalendar_Android_1371Test;
import testcase.Almanac_Calendar_Android_1043Test;
import testcase.CityManage_Calendar_Android_1360Test;
import testcase.DTLoginTest_Calendar_Android_297Test;
import testcase.DeleteNotes_Calendar_Android_723Test;
import testcase.HistoryToday_Calendar_Android_1048Test;
import testcase.Horoscope_Calendar_Android_1046Test;
import testcase.MainScreenDisplay_Calendar_Android_1359Test;
import testcase.NoteEntryAndScreenCalendar_Android_1361Test;
import testcase.QQLoginTest_Calendar_Android_297Test;
import testcase.SearchNotes_Calendar_Android_1362;
import testcase.SettingMainScreenPlug_Calendar_Android_1052Test;
import testcase.WBLoginTest_Calendar_Android_297Test;
import testcase.Weather_Calendar_Android_728Test;
@RunWith(Suite.class)
@Suite.SuiteClasses({
	//ApkInstall_Calendar_Android_775Test.class,
	
	
	MainScreenDisplay_Calendar_Android_1359Test.class,
	Almanac_Calendar_Android_1043Test.class,
	HistoryToday_Calendar_Android_1048Test.class,
	Horoscope_Calendar_Android_1046Test.class,
	Weather_Calendar_Android_728Test.class,
	CityManage_Calendar_Android_1360Test.class,
	NoteEntryAndScreenCalendar_Android_1361Test.class,
	DeleteNotes_Calendar_Android_723Test.class,
	SearchNotes_Calendar_Android_1362.class,
	SettingMainScreenPlug_Calendar_Android_1052Test.class,
	AboutUsCalendar_Android_1371Test.class,
	DTLoginTest_Calendar_Android_297Test.class,
	//验证码出现的时候会登录失败
	QQLoginTest_Calendar_Android_297Test.class,
	//验证码出现的时候会登录失败
	WBLoginTest_Calendar_Android_297Test.class,
	//ApkUninstallTest__Calendar_Android_775Test.class
	
})

public class FeatureTestSuite {
  // 此类为空,作为上面注解的载体
 
}