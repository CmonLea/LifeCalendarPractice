package testcase;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

//实现登录操作并判断是否登录成功
//@Ignore("有验证码")
public class WBLoginTest_Calendar_Android_297Test extends AbstractTest {
	public static Logger logger = Logger.getLogger(WBLoginTest_Calendar_Android_297Test.class);
	@Before
	public void setUp() {
		
		boolean iswbinstalled = driver.isAppInstalled("com.sina.weibo");
		if (iswbinstalled) {
			logger.info("手机上存在微博客户端正在卸载微博...");
			driver.removeApp("com.sina.weibo");
			if(!iswbinstalled){
				logger.info("卸载微博成功！");
			}
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		boolean alertWindow = false;// 权限提示框
		// System.out.println("aler"+alertWindow);
		try {
			alertWindow = app.permissionScreen().alertWindow.isDisplayed();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (alertWindow) {
			app.permissionScreen().allow.click();// 运行获取权限
		}

		app.mainScreen().myPageTag.click();
		if (app.myScreen().isLogin()) {
			app.myScreen().enterLogOutPage();//进入退出登录页面
			app.personalCenterScreen().logOut();//退出登录
		}

	}

	@Test(timeout=120000)
	public void testWeboLogin() {

		app.mainScreen().myPageTag.click();

		app.myScreen().enterLoginPage();

		app.loginScreen().weiboLogin("burcelea@163.com", "Test20161024");

		assertEquals("期望值为:"+"RelicRun"+"实际值为："+app.myScreen().initUserName.getText(), app.myScreen().initUserName.getText(), "RelicRun");

	}
}