package screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

public class PermissionScreen extends AbstractScreen {
	public PermissionScreen(AppiumDriver<?> driver) {
		super(driver);
	}

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "android:id/parentPanel")
	public WebElement alertWindow;

	// 华为系统弹框名称
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "android:id/alertTitle")
	public WebElement alertTitle;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.huawei.systemmanager:id/btn_allow")
	public WebElement allow;

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.huawei.systemmanager:id/btn_forbbid")
	public WebElement forbbid;

}
