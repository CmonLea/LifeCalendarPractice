package screen;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Point;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class HoroscopeScreen extends AbstractScreen {
	private Point mojie = null;

	private Point chunv = null;

	private Point baiy = null;

	private Point juxie = null;

	private Point jiniu = null;

	private Point shizi = null;

	private Point shuip = null;

	private Point tianp = null;

	private Point shesho = null;

	private Point shuangy = null;

	private Point tianx = null;

	private Point shuangz = null;

	/**
	 * 点击星座
	 * 
	 * @param horo
	 *            要切换的星座名称
	 * @return
	 */

	public Point getHoro12(String horo) {
		switch (horo) {
		case "mojie":
			logger.info("切换到摩羯座");
			mojie = new Point(getHoroScope(scopeCard12.get(0)).x,
					getHoroScope(scopeCard12.get(0)).y);
			logger.info("摩羯座的 x=" + mojie.x + "y=" + mojie.y);
			return mojie;
		case "chunv":
			logger.info("切换到处女座");
			chunv = new Point(getHoroScope(scopeCard12.get(1)).x,
					getHoroScope(scopeCard12.get(1)).y);
			logger.info("处女座的 x=" + chunv.x + "y=" + chunv.y);
			return chunv;
		case "baiy":
			logger.info("切换到白羊座");
			baiy = new Point(getHoroScope(scopeCard12.get(2)).x,
					getHoroScope(scopeCard12.get(2)).y);
			logger.info("白羊座的 x=" + baiy.x + "y=" + baiy.y);
			return baiy;
		case "juxie":
			logger.info("切换到巨蟹座");
			juxie = new Point(getHoroScope(scopeCard12.get(3)).x,
					getHoroScope(scopeCard12.get(3)).y);
			logger.info("巨蟹座的 x=" + juxie.x + "y=" + juxie.y);
			return juxie;

		case "jiniu":
			logger.info("切换到金牛座");
			juxie = new Point(getHoroScope(scopeCard12.get(4)).x,
					getHoroScope(scopeCard12.get(4)).y);
			logger.info("金牛座的 x=" + jiniu.x + "y=" + jiniu.y);
			return jiniu;
		case "shizi":
			logger.info("切换到狮子座");
			shizi = new Point(getHoroScope(scopeCard12.get(5)).x,
					getHoroScope(scopeCard12.get(5)).y);
			logger.info("狮子座的 x=" + shizi.x + "y=" + shizi.y);
			return shizi;
		case "shuip":
			logger.info("切换到水瓶座");
			shuip = new Point(getHoroScope(scopeCard12.get(6)).x,
					getHoroScope(scopeCard12.get(6)).y);
			logger.info("水瓶座的 x=" + shuip.x + "y=" + shuip.y);
			return shuip;
		case "tianp":
			logger.info("切换到天秤座");
			tianp = new Point(getHoroScope(scopeCard12.get(7)).x,
					getHoroScope(scopeCard12.get(7)).y);
			logger.info("天秤座的 x=" + tianp.x + "y=" + tianp.y);
			return tianp;
		case "shesho":
			logger.info("切换到射手座");
			shesho = new Point(getHoroScope(scopeCard12.get(8)).x,
					getHoroScope(scopeCard12.get(8)).y);
			logger.info("射手座的 x=" + shesho.x + "y=" + shesho.y);
			return shesho;
		case "shuangy":
			logger.info("切换到双鱼座");
			shuangy = new Point(getHoroScope(scopeCard12.get(9)).x,
					getHoroScope(scopeCard12.get(9)).y);
			logger.info("双鱼座的 x=" + shuangy.x + "y=" + shuangy.y);
			return shuangy;
		case "tianx":
			logger.info("切换到天蝎座");
			tianx = new Point(getHoroScope(scopeCard12.get(10)).x,
					getHoroScope(scopeCard12.get(10)).y);
			logger.info("天蝎座的 x=" + tianx.x + "y=" + tianx.y);
			return tianx;
		case "shuangz":
			logger.info("切换到双子座");
			shuangz = new Point(getHoroScope(scopeCard12.get(11)).x,
					getHoroScope(scopeCard12.get(11)).y);
			logger.info("双子座的 x=" + shuangz.x + "y=" + shuangz.y);
			return shuangz;

		}
		return null;
	}

	//
	// Point[] horoScope = { mojie, chunv, baiy, juxie, jiniu, shizi, shuip,
	// tianp, shesho, shuangy, tianx, shuangz };

	public HoroscopeScreen(AppiumDriver<?> driver) {
		super(driver);

	}
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/current_big_constellation")
	// 切换星座的控件id 星座图标
	AndroidElement changeButton;

	public AndroidElement getChangeButton() {
		return changeButton;
	}

	public AndroidElement getChangeButtonDownArrow() {
		return changeButtonDownArrow;
	}

	public List<AndroidElement> getHoroScopeCard() {
		return horoScopeCard;
	}
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/iv_constellation_choose")
	// 切换星座的下拉箭头控件id
	AndroidElement changeButtonDownArrow;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/layout_body")
	// 切换星座的下拉箭头控件id
	List<AndroidElement> horoScopeCard;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/grid_view")
	// 切换星座的下拉箭头控件id
	AndroidElement horoScopeWindow;

	public AndroidElement getHoroScopeWindow() {
		return horoScopeWindow;
	}

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(xpath = "//android.widget.GridView/android.widget.LinearLayout")
	// 切换星座的下拉箭头控件id
	List<AndroidElement> scopeCard12;
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/date_constellations")
	public AndroidElement scopeDate;
	
	
	public List<AndroidElement> getScopeCard12() {
		return scopeCard12;
	}

	/**
	 * 获取控件中心坐标
	 */
	public Point getHoroScope(AndroidElement we) {
		int x = we.getLocation().x;//获取控件的x坐标
		int y = we.getLocation().y;//获取控件的y坐标
		int height = we.getSize().height;//获取控件的高度
		int width = we.getSize().width;//获取控件的宽度
		logger.info("中心点的坐标为：" + "x=" + (x + width / 2) + "," + "y="
				+ (y + height / 2));
		Point p = new Point((x + width / 2), (y + height / 2));
		return p;

	}

}
