package testcase;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.openqa.selenium.WebElement;

import rule.TestName;
import screen.AbstractScreen;
import util.ScreenRecorder;

public class DeleteNotes_Calendar_Android_723Test extends AbstractTest {
	private Logger logger = Logger
			.getLogger(DeleteNotes_Calendar_Android_723Test.class);
	AbstractScreen as = new AbstractScreen(driver);
	private static Date date = new Date();
	private static SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
	private static String testDate = df.format(date);

	@Rule
	public TestName name = new TestName();

	// 进入记事列表，长按记事并选择删除

	// 记事能正常删除，删除后记事列表不显示该记事，如果用户为登陆状态，则我的界面个人中心云端数据根据删减的数量更新
	@Before
	public void setUp() {
		// 点击提醒
		boolean isRemindPageTagDispaly = false;
		isRemindPageTagDispaly = as.waitElentAndCapture(
				app.mainScreen().remindPageTag, "提醒标签未显示");
		if (isRemindPageTagDispaly) {
			app.mainScreen().remindPageTag.click();
		}

		// 进入普通记事
		app.remindScreen().noteItem.click();
		// 点击新建记事按钮
		app.noteScreen().getNewButton().click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		AndroidElement recordTitle = null;
		try {
			recordTitle = app.newNotesScreen().getRecordthingTitle();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		boolean isRecordTitleDisplay = false;

		isRecordTitleDisplay = as.waitElentAndCapture(recordTitle,
				"输入记事文本框尚未显示");
		if (isRecordTitleDisplay) {
			try {
				// 进入新建记事页面，输入记事标题
				app.newNotesScreen().getRecordthingTitle().sendKeys(testDate);

				// 保存记事
				app.newNotesScreen().getRecordthingSave().click();
				// 返回到首页
				app.noteScreen().getNoteBackButton().click();
			} catch (Exception e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}

		// ((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
	}

	@Test
	// @Ignore
	// 未登录情况下删除记事
	public void DelteNotes1Notlogin() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 重新进入记事页面
		// WebElement noteItem =null;
		AbstractScreen as = new AbstractScreen(driver);
		boolean isNoteItemDisplay = false;
		// noteItem = app.remindScreen().noteItem;
		isNoteItemDisplay = as.waitElentAndCapture(app.remindScreen().noteItem,
				"查找提醒页面记事栏目失败");
		if (isNoteItemDisplay) {
			app.remindScreen().noteItem.click();
		}

		TouchAction ta = new TouchAction(driver);
		WebElement notesContent = null;
		try {
			notesContent = app.noteScreen().getNotesContent().get(0);
		} catch (Exception e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 注意要执行否则无法调出菜单

		try {
			ta.longPress(notesContent, Duration.ofMillis(1500)).perform();
			app.noteScreen().getNoteDeleteButton().click();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		boolean isDeleteConfimWindoDisplay = false;
		AndroidElement deleteConfirmButton = app.noteScreen()
				.getDeleteConfimButton();
		isDeleteConfimWindoDisplay = app.noteScreen().isWidgetDisplay(
				deleteConfirmButton);
		if (isDeleteConfimWindoDisplay) {
			// 如果记事删除确认窗口显示了则点击确定删除该记事
			app.noteScreen().getDeleteConfimButton().click();
		}
		// 点击记事界面的搜索按钮，搜索是否存在删除的记事
		boolean isSeacherButtonDispaly = false;
		isSeacherButtonDispaly = as.waitElentAndCapture(app.noteScreen()
				.getSearchButton(), "没有找到记事搜索按钮");
		if (isSeacherButtonDispaly) {
			app.noteScreen().getSearchButton().click();
		}
		boolean isSearchTextDispaly = false;
		isSearchTextDispaly = as.waitElentAndCapture(app.noteScreen()
				.getSearchText(), "记事输入框未显示");
		if (isSearchTextDispaly) {
			app.noteScreen().getSearchText().sendKeys(testDate);
			app.noteScreen().getSearchTextButton().click();// 执行搜索
		}

		AndroidElement searchArea = app.noteScreen().getSearchResultArea();
		boolean isNotesDel = false;

		isNotesDel = app.noteScreen().isWidgetDisplay(searchArea);
		logger.info("正在验证记事删除是否成功...");
		if (!isNotesDel) {
			logger.info("验证记事删除成功完毕...");
		} else {
			logger.info("可能存在多条相同标题的记事！");
		}
		// 不存在删除的记事
		Assert.assertEquals("期望不显示搜索后的结果为true实际为：false", false, isNotesDel);

		// 退回到提醒页面,退出搜索页面
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		// 退出到首页
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	@Test
	// 登录情况下删除记事
	public void DeleteNotes2Login() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isMapageTagDisypaly = false;
		isMapageTagDisypaly = as.waitElentAndCapture(
				app.mainScreen().myPageTag, "我的标签未显示");
		if (isMapageTagDisypaly) {
			app.mainScreen().myPageTag.click();
		}

		if (app.myScreen().isLogin()) {
			app.myScreen().enterLogOutPage();// 进入退出登录页面
			app.personalCenterScreen().logOut();// 退出登录
		}
		boolean isMyTagDisplay = false;
		isMyTagDisplay = as.waitElentAndCapture(app.mainScreen().myPageTag,
				"主界面我的标签未显示");
		if (isMyTagDisplay) {
			app.mainScreen().myPageTag.click();
		}

		app.myScreen().enterLoginPage();

		app.loginScreen().login("apple04", "123456");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e2) {
			// TODO 自动生成的 catch 块
			e2.printStackTrace();
		}
		// 进入个人中心
		boolean isPersonInfoDisplay = false;
		isPersonInfoDisplay = as.waitElentAndCapture(
				app.myScreen().personalInfo, "没有找到个人中心页面");
		if (isPersonInfoDisplay) {
			app.myScreen().personalInfo.click();
		}

		// 用户记事数据
		AndroidElement customeData = app.personalCenterScreen().getCloudsData();

		boolean isCustomeDataDisplay = false;

		isCustomeDataDisplay = as.waitElentAndCapture(customeData, "用户数据没有显示");
		String cloudsData = null;
		if (isCustomeDataDisplay) {
			cloudsData = app.personalCenterScreen().getCloudsData().getText();

			if (!cloudsData.equals("正在同步中....")) {

				cloudsData = app.personalCenterScreen().getCloudsData()
						.getText().split("条")[0];
				logger.info("删除前用户数据为：" + cloudsData + "条");
			} else {
				logger.info("数据未同步完成,正在等待数据同步完成...");
				int i = 0;
				while (i < 120) {
					try {
						Thread.sleep(1000);
						cloudsData = app.personalCenterScreen().getCloudsData()
								.getText();
						logger.info("当前等待时间为：" + (i + 1) + "秒");
					} catch (InterruptedException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}

					if (cloudsData.contains("条")) {
						cloudsData = app.personalCenterScreen().getCloudsData()
								.getText().split("条")[0];
						break;
					}
					i++;
				}

			}

		}

		// as.waitElentAndCapture(we, fileName);

		// 获取云端数据

		int cldata = Integer.valueOf(cloudsData);

		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);

		boolean isRemindPageTagDis = false;

		isRemindPageTagDis = as.waitElentAndCapture(
				app.mainScreen().remindPageTag, "提醒标签未显示");
		if (isRemindPageTagDis) {
			app.mainScreen().remindPageTag.click();
		}

		// app.remindScreen().noteItem.click();

		// 重新进入记事页面
		WebElement noteItem = app.remindScreen().noteItem;
		AbstractScreen as = new AbstractScreen(driver);
		boolean isNoteItemDisplay = false;
		isNoteItemDisplay = as.waitElentAndCapture(noteItem, "查找提醒页面记事栏目失败");
		if (isNoteItemDisplay) {
			app.remindScreen().noteItem.click();
		}

		TouchAction ta = new TouchAction(driver);
		WebElement notesContent = null;
		try {
			notesContent = app.noteScreen().getNotesContent().get(0);
		} catch (Exception e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 注意要执行否则无法调出菜单

		try {
			ta.longPress(notesContent, Duration.ofMillis(1500)).perform();
			app.noteScreen().getNoteDeleteButton().click();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		boolean isDeleteConfimWindoDisplay = false;
		AndroidElement deleteConfirmButton = app.noteScreen()
				.getDeleteConfimButton();
		isDeleteConfimWindoDisplay = app.noteScreen().isWidgetDisplay(
				deleteConfirmButton);
		if (isDeleteConfimWindoDisplay) {
			// 如果记事删除确认窗口显示了则点击确定删除该记事
			app.noteScreen().getDeleteConfimButton().click();
		}
		// 点击记事界面的搜索按钮，搜索是否存在删除的记事
		app.noteScreen().getSearchButton().click();
		app.noteScreen().getSearchText().sendKeys("删除记事测试" + testDate);
		app.noteScreen().getSearchTextButton().click();
		AndroidElement searchArea = app.noteScreen().getSearchResultArea();
		boolean isNotesDel = false;

		isNotesDel = app.noteScreen().isWidgetDisplay(searchArea);
		logger.info("正在验证记事删除是否成功...");
		if (!isNotesDel) {
			logger.info("验证记事删除成功完毕...");
		} else {
			logger.info("可能存在多条相同标题的记事！");
		}
		// 不存在删除的记事
		Assert.assertEquals("期望不显示搜索后的结果为true实际为：false", false, isNotesDel);

		// 返回到首页
		app.noteScreen().getSearchCancelButton().click();

		// ((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);

		try {
			app.noteScreen().getNoteBackButton().click();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		app.mainScreen().myPageTag.click();
		// 我的页面
		app.myScreen().personalInfo.click();

		boolean isafterDeleteDataDisplay = false;
		AndroidElement customeDeleteData = app.personalCenterScreen()
				.getCloudsData();
		isafterDeleteDataDisplay = as.waitElentAndCapture(customeDeleteData,
				"用户数据没有显示");
		String afterDeleteData = null;

		if (isafterDeleteDataDisplay) {
			afterDeleteData = app.personalCenterScreen().getCloudsData()
					.getText().split("条")[0];
			logger.info("删除后用户数据为：" + afterDeleteData);
		}

		int afcldata = Integer.valueOf(afterDeleteData);
		logger.info("正在验证用户数据是否正确...");
		Assert.assertEquals("删除后的数据为之前的数据减1", cldata - 1, afcldata);
		logger.info("用户数据验证完毕...");
		// 退出登录,避免影响其他用例
		app.personalCenterScreen().logOut();

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

}
