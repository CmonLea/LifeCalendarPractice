package testcase;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.StartsActivity;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import rule.TestName;
import screen.AbstractScreen;
import testcase.AbstractTest;
import util.ScreenRecorder;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AboutUsCalendar_Android_1371Test extends AbstractTest {
	@Rule 
	public TestName name = new TestName();
	private Logger logger = Logger
			.getLogger(AboutUsCalendar_Android_1371Test.class);
	AbstractScreen as = new AbstractScreen(driver);
	private static Date date = new Date();
	private static SimpleDateFormat df = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");
	private static String testDate = df.format(date);
	
	@Before
	public void setup() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 如果弹升级框就点掉

		boolean isUpdateWindowDisplay = false;
		isUpdateWindowDisplay = as.waitElentAndCapture(app.mainScreen()
				.getUpdateWindow(), "升级框截图");

		// 点掉升级框
		if (isUpdateWindowDisplay) {
			logger.info("检测到有升级框弹出，正在解除障碍！");
			boolean isCancelButtonDisplay = false;
			isCancelButtonDisplay = as.waitElentAndCapture(app.mainScreen()
					.getUpdateCancelbutton(), "等待取消按钮显示");
			if (isCancelButtonDisplay) {
				app.mainScreen().getUpdateCancelbutton().click();
				logger.info("KO升级框！Perfect！");
			}

		}
		// 没有显示则循环查找升级框，查找10s后确实没显示即真的没有显示升级框往下操作
		int i = 1;
		while (!isUpdateWindowDisplay) {
			try {
				// 休眠1s钟查看是否显示
				logger.info("暂时没有显示升级框正在休眠" + i + "秒等待升级框显示...");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			// 再次查看是否显示
			isUpdateWindowDisplay = as.waitElentAndCapture(app.mainScreen()
					.getUpdateWindow(), "升级框截图");
			// 点掉升级框
			if (isUpdateWindowDisplay) {
				logger.info("检测到有升级框弹出，正在解除障碍！");
				boolean isCancelButtonDisplay = false;
				isCancelButtonDisplay = as.waitElentAndCapture(app.mainScreen()
						.getUpdateCancelbutton(), "等待取消按钮显示");
				if (isCancelButtonDisplay) {
					app.mainScreen().getUpdateCancelbutton().click();
					logger.info("KO升级框！Perfect！");
				}
				break;
			}

			if (i == 10) {
				logger.info("等待了" + i + "秒没有显示升级框！");
				break;
			}
			i++;
		}

	}
	// 步骤：点击我的-关于我们

	// 期望：版本等信息显示正确
	@Test
	// @Ignore
	public void test1AboutUs() {
//		as.takeScreenShot("截图测试");

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}

		// 点击我的
		boolean isMyPageTageDispaly = false;
		isMyPageTageDispaly = as.waitElentAndCapture(
				app.mainScreen().myPageTag, "我的标签未显示");
		if (isMyPageTageDispaly) {
			logger.info("点击我的标签");
			app.mainScreen().myPageTag.click();
		}
		boolean isAboutUsdis = false;
		isAboutUsdis = as.waitElentAndCapture(app.myScreen().getAboutUs(),
				"关于页面未你找到");
		if (isAboutUsdis) {
			app.myScreen().getAboutUs().click();
		}
		AndroidElement offisite = null;
		try {
			offisite = app.aboutUsScreen().getAboutUsText().get(0);
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		if (offisite != null) {
			String officialSite = app.aboutUsScreen().getAboutUsText().get(0)
					.getText();

			Assert.assertEquals(
					"官方网址期望值为：rili.160.com" + "实际为：" + officialSite,
					"rili.160.com", officialSite);
		} else {
			boolean isOffisite = as.waitElentAndCapture(offisite, "查找官网失败");
			if (isOffisite) {
				String officialSite = app.aboutUsScreen().getAboutUsText()
						.get(0).getText();

				Assert.assertEquals("官方网址期望值为：rili.160.com" + "实际为："
						+ officialSite, "rili.160.com", officialSite);
			}
		}

		AndroidElement qq = null;
		try {
			qq = app.aboutUsScreen().getAboutUsText().get(1);
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		if (qq != null) {
			String QQ = app.aboutUsScreen().getAboutUsText().get(1).getText();

			Assert.assertEquals("QQ期望值为：QQ群:73354296" + "实际为：" + QQ,
					"QQ群:73354296", QQ);
		} else {
			boolean isQq = as.waitElentAndCapture(qq, "查找官网失败");
			if (isQq) {
				String QQ = app.aboutUsScreen().getAboutUsText().get(1)
						.getText();
				Assert.assertEquals("QQ期望值为：QQ群:73354296" + "实际为：" + QQ,
						"QQ群:73354296", QQ);
			}
		}

		AndroidElement webo = null;
		try {
			webo = app.aboutUsScreen().getAboutUsText().get(2);
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		if (webo != null) {
			String web = app.aboutUsScreen().getAboutUsText().get(2).getText();

			Assert.assertEquals("微博期望值为：weibo.com/160rili" + "实际为：" + web,
					"weibo.com/160rili", web);
		} else {
			boolean isWeb = as.waitElentAndCapture(webo, "查找官网失败");
			if (isWeb) {
				String web = app.aboutUsScreen().getAboutUsText().get(2)
						.getText();

				Assert.assertEquals("微博期望值为：weibo.com/160rili" + "实际为：" + web,
						"weibo.com/160rili", web);
			}
		}
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	// 步骤：点击我的-给我好评

	// 期望：调出手机安装的应用管理市场，评价成功
	//
	@Test
	@Ignore("仅适用于华为手机")
	public void test2GoodComment() {
		try {
			ScreenRecorder.StartScreenRecording("test2GoodComment()");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		app.mainScreen().myPageTag.click();
		app.myScreen().getGoodComment().click();
		String alterTitle = app.permissionScreen().alertTitle.getText();
		Assert.assertEquals("期望alertTitle为：使用以下方式打开，实际为：" + alterTitle,
				"使用以下方式打开", alterTitle);
	
	try {
		ScreenRecorder.StopScreenRecording("test2GoodComment()", "recordFolder", true);
	} catch (IOException e) {
		// TODO 自动生成的 catch 块
		e.printStackTrace();
	} catch (InterruptedException e) {
		// TODO 自动生成的 catch 块
		e.printStackTrace();
	}
	}

	// 步骤：点击我的-意见反馈，输入反馈内容，点击发送

	// 期望：反馈成功
	@Test
	public void test3FeedBack() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		
		// as.takeScreenShot("反馈页面截图");
		boolean isMyTagDisplay = false;
		isMyTagDisplay = as.waitElentAndCapture(app.mainScreen().myPageTag,
				"我的标签未显示");
		if (isMyTagDisplay) {
			app.mainScreen().myPageTag.click();
		}

		boolean isAccoutInfoDisplay = false;
		isAccoutInfoDisplay = as.waitElentAndCapture(
				app.myScreen().accountInfo, "个人中心");
		if (isAccoutInfoDisplay) {
			as.swipeWidget2Up((AndroidDriver<?>)driver, app.myScreen().accountInfo, 0);
			//as.swipeWidget2Up(app.myScreen().accountInfo, "滑动个人信息控件", 300);
		}
		boolean isOptionFeedDis = false;
		isOptionFeedDis = as.waitElentAndCapture(
				app.myScreen().getOptionFeed(), "我的关于我们页面");
		if (isOptionFeedDis) {
			app.myScreen().getOptionFeed().click();
		}

		// 输入反馈信息
		boolean isFeedEditDispaly = false;
		isFeedEditDispaly = as.waitElentAndCapture(app.feedBackScreen()
				.getFeedEdit(), "查找反馈输入框失败");
		if (isFeedEditDispaly) {
			app.feedBackScreen().getFeedEdit()
					.sendKeys("TestFeedBack" + testDate);
			// 发送
			app.feedBackScreen().getSendButton().click();
		}

		// ((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		List<AndroidElement> feedList = app.feedBackScreen().getFeedContent();
		List<AndroidElement> sendTimeList = app.feedBackScreen().getSendTime();
		List<String> feedTextList = new ArrayList<String>();
		List<String> sendTime = new ArrayList<String>();

		AndroidElement androidWidgit = null;

		boolean isAndroidWidgit = false;
		isAndroidWidgit = as.waitElentAndCapture(app.feedBackScreen()
				.getFeedBackWindow(), "反馈窗口未显示");
		int x = 0;
		int y = 0;
		int y1 = 0;
		if (isAndroidWidgit) {
			androidWidgit = app.feedBackScreen().getFeedBackWindow();
			x = androidWidgit.getCenter().x;
			y = androidWidgit.getLocation().y;
			y1 = androidWidgit.getLocation().y
					+ androidWidgit.getSize().getHeight();

			logger.info("从x=" + x + "y=" + y1 + "滑动到" + "x=" + x + "y=" + y);
		}

		TouchAction ta = new TouchAction(driver);

		String lastestFeed = null;
		for (int i = 0; i < feedList.size(); i++) {
			logger.info("反馈的信息为：" + feedList.get(i).getText());
			feedTextList.add(feedList.get(i).getText());

		}
		boolean isFeedContentDisplay = false;
		isFeedContentDisplay = as.waitElentAndCapture(app.feedBackScreen()
				.getFeedContent().get(feedTextList.size() - 1), "反馈内容");
		if (isFeedContentDisplay) {
			lastestFeed = app.feedBackScreen().getFeedContent()
					.get(feedTextList.size() - 1).getText();
			logger.info("反馈的条数第一屏的长度为：" + feedTextList.size() + "条，内容为："
					+ lastestFeed);
		}

		// 获取发布反馈的时间
		for (int i = 0; i < sendTimeList.size(); i++) {
			logger.info("反馈的时间为：" + sendTimeList.get(i).getText());
			sendTime.add(sendTimeList.get(i).getText());

		}
		// 获取最后一条反馈的发布时间，如果没获取到就往下滑动否则视为没有获取到完整的列表
		while (feedTextList.size() != sendTime.size()) {
			ta.longPress(x, y1 - 50).moveTo(x, y).release().perform();
			try {
				Thread.sleep(2000);
				// 再获取一次实时长度
				feedList = app.feedBackScreen().getFeedContent();
				for (int i = 0; i < feedList.size(); i++) {
					logger.info("反馈的信息为：" + feedList.get(i).getText());
					feedTextList.add(feedList.get(i).getText());

				}
				sendTimeList = app.feedBackScreen().getSendTime();
				for (int i = 0; i < sendTimeList.size(); i++) {
					logger.info("反馈的时间为：" + sendTimeList.get(i).getText());
					sendTime.add(sendTimeList.get(i).getText());

				}

			} catch (InterruptedException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			if (feedTextList.size() == sendTime.size()) {
				logger.info("已经滑到底了！");

				logger.info("反馈list列表长度为：" + feedTextList.size());
				lastestFeed = app.feedBackScreen().getFeedContent()
						.get(feedTextList.size() - 1).getText();

				break;
			}
		}

		String exceptedContent = "TestFeedBack" + testDate;
		Assert.assertEquals("判断验证是否反馈成功", exceptedContent, lastestFeed);
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(), "recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	@After
	public void teaeDown() {
		Activity ac = new Activity("com.updrv.lifecalendar",
				".activity.MainActivity");

		((StartsActivity) driver).startActivity(ac);
	}
}
