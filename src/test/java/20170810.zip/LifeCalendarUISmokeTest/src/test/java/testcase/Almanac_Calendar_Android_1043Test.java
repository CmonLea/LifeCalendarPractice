package testcase;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import io.appium.java_client.android.AndroidDriver;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import rule.*;
import screen.AbstractScreen;
import testcase.AbstractTest;
import util.ScreenRecorder;

public class Almanac_Calendar_Android_1043Test extends AbstractTest {

	private static Logger logger = Logger
			.getLogger(Almanac_Calendar_Android_1043Test.class);
	AbstractScreen as = new AbstractScreen(driver);
	@Rule
	public TestName name = new TestName();

	@Before
	public void setup() {
		// 如果弹升级框就点掉

		boolean isUpdateWindowDisplay = false;
		isUpdateWindowDisplay = as.isWidgetDisplay(app.mainScreen()
				.getUpdateWindow());
		if (isUpdateWindowDisplay) {
			logger.info("检测到有升级框弹出，正在解除障碍！");
			boolean isCancelButtonDisplay = false;
			isCancelButtonDisplay = as.waitElentAndCapture(app.mainScreen()
					.getUpdateCancelbutton(), "等待取消按钮显示");
			if (isCancelButtonDisplay) {
				app.mainScreen().getUpdateCancelbutton().click();
				logger.info("KO升级框！Perfect！");
			}

		} else {
			logger.info("没有显示升级框！");
		}
	}

	// 日历主界面点击“黄历信息”区域
	//
	// 步骤：1、进入到当天黄历详情界面
	//
	// 期望：2、界面文字、图片显示正常无乱码错位
	@Test
	public void testAlmanac1() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isCalendarScreen = false;
		isCalendarScreen = as.waitElentAndCapture(
				app.mainScreen().calendarScreen, "主界面日历未找到");
		if (isCalendarScreen) {

//			app.mainScreen().swipeWidget2Up(app.mainScreen().calendarScreen,
//					"日历控件", 500);
			
			as.swipeWidget2Up((AndroidDriver<?>)driver,app.mainScreen().calendarScreen , 500);
		
		}

		boolean isAlmanacWidgetDisplay = false;
		isAlmanacWidgetDisplay = app.mainScreen().almanacWidget.isDisplayed();
		if (isAlmanacWidgetDisplay) {
			app.mainScreen().almanacWidget.click();// 目前这个概率性会点击到其他控件上，不知什么原因
		} else {
			AbstractScreen as = new AbstractScreen(driver);
			isAlmanacWidgetDisplay = as.waitElentAndCapture(
					app.mainScreen().almanacWidget, "黄历控件");
			if (isAlmanacWidgetDisplay) {
				app.mainScreen().almanacWidget.click();

			}
		}

		// Activity activity = new Activity("com.updrv.lifecalendar",
		// ".activity.AlmanacActivity");
		String currentActivity = ((AndroidDriver<?>) driver).currentActivity();
		if (currentActivity.equals(".activity.AlmanacActivity")) {
			// 判断是否为黄历页面
			Assert.assertEquals("期望值为：.activity.AlmanacActivity" + "实际值为："
					+ currentActivity, ".activity.AlmanacActivity",
					currentActivity);
		} else {
			logger.error("页面跳转错误！");
			AbstractScreen as = new AbstractScreen(driver);
			as.takeScreenShot("页面跳转错误！");
			Assert.assertEquals("期望值为：.activity.AlmanacActivity" + "实际值为："
					+ currentActivity, ".activity.AlmanacActivity",
					currentActivity);
		}

		try {
		ScreenRecorder.StopScreenRecording(name.getMethodName(),
				"recordFolder", true);
	} catch (IOException e) {
		// TODO 自动生成的 catch 块
		e.printStackTrace();
	} catch (InterruptedException e) {
		// TODO 自动生成的 catch 块
		e.printStackTrace();
	}

	}

	//
	// 步骤：黄历详情界面，点击向左、向右切换按钮
	//
	// 期望：正常切换黄历详情页，信息正确，非今天显示今
	@Test
	// @Ignore("暂时无法测试，需要开发那边配合增加控件描述信息，不然左右切换按钮会被标识为NAF(Not Accessibility Friendly)")
	public void testAlmanac2() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 滑动日历并点击黄历
//		app.mainScreen().swipeWidget2Up(app.mainScreen().calendarScreen,
//				"日历控件", 500);
		as.swipeWidget2Up((AndroidDriver<?>)driver,app.mainScreen().calendarScreen , 500);
		app.mainScreen().almanacWidget.click();// 目前这个概率性会点击到其他控件上，不知什么原因
		String currentActivity = ((AndroidDriver<?>) driver).currentActivity();
		if(!currentActivity.equals(".activity.AlmanacActivity")){
			logger.info("页面跳转错误正在截图...");
			as.takeScreenShot(name.getMethodName());
			
		}
		String currentSolarCalendar1 = null;
		try {
			currentSolarCalendar1 = app.almanacScreen().yangli.getText();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		Date dNow = new Date(); // 当前时间
		Date dBefore = new Date();// 当前时间之前的某天
		Date dAfter = new Date();// 当前时间往后的某天
		Calendar calendar = Calendar.getInstance(); // 得到日历

		calendar.setTime(dNow);// 把当前时间赋给日历
		calendar.add(Calendar.DAY_OF_MONTH, -1); // 设置为前一天
		dBefore = calendar.getTime(); // 得到前一天的时间

		calendar.setTime(dNow);
		calendar.add(Calendar.DAY_OF_MONTH, 1); // 设置为后一天
		dAfter = calendar.getTime(); // 得到后一天的时间
		// dNow.getMonth()
		SimpleDateFormat sdf = null; // 设置时间格式
		SimpleDateFormat month = new SimpleDateFormat("M");
		SimpleDateFormat day = new SimpleDateFormat("d");
		// 判断当前日期月份
		int currentMonth = Integer.valueOf(month.format(dNow));
		int currentDay = Integer.valueOf(day.format(dNow));
		// 由于手机UI上显示的日期格式不统一故需要分别处理
		if (currentMonth < 9) {
			logger.info("当前月份小于9月");

			if (currentDay < 9) {
				logger.info("当前天小于9为：" + currentDay);
				sdf = new SimpleDateFormat("yyyy年M月d日"); // 设置时间格式
			} else {
				logger.info("当前天大于9为：" + currentDay);
				sdf = new SimpleDateFormat("yyyy年M月dd日");

			}

		} else {
			logger.info("当前月份为：" + currentMonth);
		}
		// 当前月份数大于9需要另行设置月份的格式
		if (currentMonth > 9) {
			logger.info("当前月份大于9月");
			if (currentDay <=9) {
				logger.info("当前天：" + currentDay + "数小于9");
				sdf = new SimpleDateFormat("yyyy年MM月d日"); // 设置时间格式
			} else {
				logger.info("当前天：" + currentDay + "数大于于9");
				sdf = new SimpleDateFormat("yyyy年MM月dd日");

			}
		} else {
			logger.info("当前月份为：" + currentMonth);
		}

		String beforeCurrentDate = sdf.format(dBefore); // 格式化前一天
		String currentDate = sdf.format(dNow); // 格式化当前时间
		String afterCurrentDate = sdf.format(dAfter);// 当前日期往后一天
		// 进入后向左点击切换黄历日期

		logger.info("向左切换日期...");
		// for(int i=0;i<2;i++){
		boolean isLeftDis = false;
		isLeftDis = as.waitElentAndCapture(app.almanacScreen().left,
				"黄历向左切换按钮未显示");
		if (isLeftDis) {
			app.almanacScreen().left.click();
		}

		// 点击后再次获取显示的阳历日期
		boolean isSolarCalendar2 = false;
		isSolarCalendar2 = as.waitElentAndCapture(app.almanacScreen().yangli,
				"阳历未显示");
		String currentSolarCalendar2 = null;
		if (isSolarCalendar2) {
			currentSolarCalendar2 = app.almanacScreen().yangli.getText();
		}

		// }

		// 断言操作后的显示日期为当前日期往前一天
		Assert.assertEquals("期望往左点击后的日期为：" + beforeCurrentDate + "实际为："
				+ currentSolarCalendar2, beforeCurrentDate,
				currentSolarCalendar2);
		// 并且显示今字图标

		boolean isTodayIconDisplay = false;
		isTodayIconDisplay = app.almanacScreen().todayIcon.isDisplayed();

		Assert.assertTrue(
				"期望isTodayIconDisplay为true，实际为：" + isTodayIconDisplay,
				isTodayIconDisplay);

		for (int i = 0; i < 2; i++) {
			app.almanacScreen().right.click();
			String currentSolarCalendar3 = app.almanacScreen().yangli.getText();
			try {

			} catch (Exception e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			if (i == 0) {

				try {
					boolean isTodayIconDisplay2 = app.almanacScreen().todayIcon
							.isDisplayed();// 重新获取是否显示今字图标
					if (isTodayIconDisplay2) {
						isTodayIconDisplay2 = true;
					} else {
						isTodayIconDisplay2 = false;
					}
					// 返回到当前日期且不显示今字图标

					Assert.assertEquals("期望往右点击1次后的日期为："
							+ currentSolarCalendar1 + "实际为："
							+ currentSolarCalendar3, currentDate,
							currentSolarCalendar3);
					// Assert.assertFalse("期望isTodayIconDisplay为false，实际为："
					// + isTodayIconDisplay, isTodayIconDisplay);
					Assert.assertTrue("期望isTodayIconDisplay为false，实际为："
							+ isTodayIconDisplay2, !isTodayIconDisplay2);
				} catch (Exception e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

			}
			if (i == 1) {

				boolean isTodayIconDisplay2 = app.almanacScreen().todayIcon
						.isDisplayed();// 重新获取是否显示今字图标
				if (isTodayIconDisplay2) {
					isTodayIconDisplay2 = true;
				} else {
					isTodayIconDisplay2 = false;
				}

				// 往右再点一次回到当前日期后一天，并显示今字图标
				Assert.assertEquals("期望往右点击2次后的日期为：" + afterCurrentDate
						+ "实际为：" + currentSolarCalendar3, afterCurrentDate,
						currentSolarCalendar3);

				Assert.assertTrue("期望isTodayIconDisplay为true，实际为："
						+ isTodayIconDisplay2, isTodayIconDisplay2);

			}
		}
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}
