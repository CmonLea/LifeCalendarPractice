package rule;

import org.junit.rules.TestWatcher;
import org.junit.runner.Description;

public class TestName extends TestWatcher {
 private String fName;
 @Override
 protected void starting(Description d) {
	 fName = d.getClassName() + "." + d.getMethodName();
 }
 /**
  * @return 返回当前运行类的测试方法
  */
 public String getMethodName() {
  return fName;
 }
 


}