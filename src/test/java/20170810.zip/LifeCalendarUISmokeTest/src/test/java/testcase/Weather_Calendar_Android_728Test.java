package testcase;

import static org.junit.Assert.assertTrue;

import java.io.IOException;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;

import rule.TestName;
import screen.AbstractScreen;
import testcase.AbstractTest;
import util.ScreenRecorder;

public class Weather_Calendar_Android_728Test extends AbstractTest {
	public static Logger logger = Logger
			.getLogger(Weather_Calendar_Android_728Test.class);
     AbstractScreen as =new AbstractScreen(driver);
	@Rule
	public TestName name = new TestName();

	// 步骤：1、点击主界面天气信息模块2、点击语音播报按钮
	//
	// 期望：1、正常进入到天气详情模块，天气，24小时数据，空气，生活等数据显示正确
	//
	// 2、语音播放正确（注意上午，下午的播放）//无法验证

	@Test
	public void testWeather() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// app.mainScreen().myPageTag.click();
//		app.mainScreen().swipeWidget2Up(app.mainScreen().calendarScreen,
//				"日历控件", 500);
		as.swipeWidget2Up((AndroidDriver<?>) driver, app.mainScreen().calendarScreen, 500);
		boolean isweatherWidgetDisplay = app.mainScreen().isWidgetDisplay(
				app.mainScreen().weatherWidget);
		if (isweatherWidgetDisplay) {
			logger.info("识别到天气控件，正在点击天气控件...");
			app.mainScreen().weatherWidget.click();
			logger.info("点击完毕...");
			String currentActivity = ((AndroidDriver<?>) driver)
					.currentActivity();
			logger.info("判断是否进入天气页面...");
			Assert.assertEquals("期望值为：.activity.weather.WeatherNewActivity"
					+ "实际值为：" + currentActivity,
					".activity.weather.WeatherNewActivity", currentActivity);
			logger.info("已处于天气页面...");

		} else {
			logger.info("未识别到天气控件，正在滑动黄历控件...");
			// 滑动黄历控件
//			app.mainScreen().swipeWidget2Up(app.mainScreen().almanacWidget,
//					"黄历控件", 500);
			as.swipeWidget2Up((AndroidDriver<?>) driver, app.mainScreen().almanacWidget, 0);
			isweatherWidgetDisplay = app.mainScreen().isWidgetDisplay(
					app.mainScreen().weatherWidget);

			if (isweatherWidgetDisplay) {
				logger.info("识别到天气控件，正在点击天气控件...");
				app.mainScreen().weatherWidget.click();
				logger.info("点击完毕...");
				String currentActivity = ((AndroidDriver<?>) driver)
						.currentActivity();
				logger.info("判断是否进入天气页面...");
				Assert.assertEquals("期望值为：.activity.weather.WeatherNewActivity"
						+ "实际值为：" + currentActivity,
						".activity.weather.WeatherNewActivity", currentActivity);
				logger.info("已处于天气页面...");

			}

		}
		AndroidElement mainWeaterArea = app.weatherScreen()
				.getMainWeatherArea();
		try {
			boolean ismainWeaterAreaDisplay = app.weatherScreen()
					.isElementDisplayed(mainWeaterArea);
			if (ismainWeaterAreaDisplay) {
				assertTrue("验证主天气控件是否显示", ismainWeaterAreaDisplay);
			}
			// 滑动主天气控件
			//app.mainScreen().swipeWidget2Up(mainWeaterArea, "主天气控件", 900);
			as.swipeWidget2Up((AndroidDriver<?>) driver, mainWeaterArea, 0);
			// 查看是否显示7天天气区域
			AndroidElement weater7Area = app.weatherScreen().getWeather7Area();
			boolean isWeater7AreaDisplay = app.weatherScreen()
					.isElementDisplayed(weater7Area);

			assertTrue("验证7天天气控件是否显示", isWeater7AreaDisplay);

			// 滑动主7天天气控件
			//app.mainScreen().swipeWidget2Up(weater7Area, "7天天气控件", 800);
			as.swipeWidget2Up((AndroidDriver<?>) driver,weater7Area, 0);
			// 查看是否显示24小时天气区域
			AndroidElement weater24Area = app.weatherScreen()
					.getWeather24Area();
			boolean isWeater24AreaDisplay = app.weatherScreen()
					.isElementDisplayed(weater24Area);

			assertTrue("验证24小时天气控件是否显示", isWeater24AreaDisplay);

			// 查看是否显示AQI天气区域
			AndroidElement weaterAQIArea = app.weatherScreen()
					.getWeather24Area();
			boolean isWeaterAQIAreaDisplay = app.weatherScreen()
					.isElementDisplayed(weaterAQIArea);
			// 验证是否显示AQI区域
			assertTrue("验证AQI天气控件是否显示", isWeaterAQIAreaDisplay);

			// 查看是否显示生活天气区域
			AndroidElement weaterLifeArea = app.weatherScreen()
					.getWeather24Area();
			boolean isWeaterLifeAreaDisplay = app.weatherScreen()
					.isElementDisplayed(weaterLifeArea);

			if (isWeaterLifeAreaDisplay) {
				// 验证是否显示生活指数控件
				assertTrue("验证生活天气控件是否显示", isWeaterLifeAreaDisplay);
			} else {
				// 滑动主24小时天气控件
				//app.mainScreen().swipeWidget2Up(weater24Area, "24小时天气控件", 500);
				as.swipeWidget2Up((AndroidDriver<?>) driver,weater24Area, 0);
				isWeaterLifeAreaDisplay = app.weatherScreen()
						.isElementDisplayed(weaterLifeArea);
				// 验证是否显示生活指数区域
				assertTrue("验证生活天气控件是否显示", isWeaterLifeAreaDisplay);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}
