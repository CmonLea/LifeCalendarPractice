package testcase;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;

import org.apache.log4j.Logger;
import org.junit.Test;

import rule.TestName;
import screen.AbstractScreen;
import testcase.AbstractTest;
import util.ScreenRecorder;

//@Ignore("尚未实现")
//@RunWith(Parameterized.class)
public class Horoscope_Calendar_Android_1046Test extends AbstractTest {
	static String[] horoScope = { "mojie", "chunv", "baiy", "juxie", "jiniu",
			"shizi", "shuip", "tianp", "shesho", "shuangy", "tianx", "shuangz" };
	int scopeIndex = (int) (Math.random() * 13);
	@Rule
	public TestName name = new TestName();

	// 步骤1：主界面点击星座区域块
	// 步骤2：星座详情页数据显示正常，与星座网一致
	private static Logger logger = Logger
			.getLogger(Horoscope_Calendar_Android_1046Test.class);
	AbstractScreen as = new AbstractScreen(driver);

	@Before
	public void setup() {
		// 如果弹升级框就点掉

		boolean isUpdateWindowDisplay = false;
		isUpdateWindowDisplay = as.waitElentAndCapture(app.mainScreen()
				.getUpdateWindow(), "升级框截图");
		if (isUpdateWindowDisplay) {
			logger.info("检测到有升级框弹出，正在解除障碍！");
			boolean isCancelButtonDisplay = false;
			isCancelButtonDisplay = as.waitElentAndCapture(app.mainScreen()
					.getUpdateCancelbutton(), "等待取消按钮显示");
			if (isCancelButtonDisplay) {
				app.mainScreen().getUpdateCancelbutton().click();
				logger.info("KO升级框！Perfect！");
			}

		} else {
			logger.info("没有显示升级框！");
		}
	}

	@Test
	// @Ignore
	public void testHoroscopeDetailpage() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isCalendarScreenDisplayed = false;
		try {
			isCalendarScreenDisplayed = app.mainScreen().calendarScreen
					.isDisplayed();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		AndroidElement calendarScreen = null;
		if (isCalendarScreenDisplayed) {
			// 滑动日历控件
			calendarScreen = app.mainScreen().calendarScreen;
			// app.mainScreen().swipeWidget2Up(calendarScreen, "日历控件", 500);
			as.swipeWidget2Up((AndroidDriver<?>) driver, calendarScreen, 500);

		} else {

			isCalendarScreenDisplayed = as.waitElentAndCapture(
					app.mainScreen().calendarScreen, "日历控件未找到");
			if (isCalendarScreenDisplayed) {
				calendarScreen = app.mainScreen().calendarScreen;
				as.swipeWidget2Up((AndroidDriver<?>) driver, calendarScreen,
						500);
				// app.mainScreen().swipeWidget2Up(calendarScreen, "日历控件", 500);
			}

		}

		boolean isAlmanac = false;
		isAlmanac = app.mainScreen().almanacWidget.isDisplayed();
		AndroidElement AlmanacWidget;
		if (isAlmanac) {
			AlmanacWidget = app.mainScreen().almanacWidget;
			// 滑动黄历控件
			// app.mainScreen().swipeWidget2Up(AlmanacWidget, "黄历历控件", 500);
			try {
				as.swipeWidget2Up((AndroidDriver<?>) driver, AlmanacWidget, 100);
			} catch (Exception e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			}
			boolean isHoroDlp = false;
			isHoroDlp = as.waitElentAndCapture(
					app.mainScreen().horoscopeWidget, "定位星座控件失败");
			int i = 0;
			while (!isHoroDlp) {
				logger.info("滑动不到位,正在继续滑动...当前尝试第" + (i + 1) + "次");
				// app.mainScreen().swipeWidget2Up(AlmanacWidget, "黄历历控件", 500);
				as.swipeWidget2Up((AndroidDriver<?>) driver, AlmanacWidget, 0);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}

				isHoroDlp = app.mainScreen().isWidgetDisplay(
						app.mainScreen().horoscopeWidget);
				if (i == 10) {
					logger.info("尝试10次无果...");
					break;
				}
				if (isHoroDlp) {
					break;
				}

				i++;
			}
			AndroidElement horoWidget = null;
			if (isHoroDlp) {
				horoWidget = app.mainScreen().horoscopeWidget;
				horoWidget.click();
			} else {
				logger.info("正在等待星座控件显示...");
				isHoroDlp = as.waitElentAndCapture(horoWidget, "星座控件未显示");
				if (isHoroDlp) {
					horoWidget = app.mainScreen().horoscopeWidget;
					horoWidget.click();
					String currentActivity = ((AndroidDriver<?>) driver)
							.currentActivity();
					String exceptedActivity = ".activity.ConstellationsActivity";
					Assert.assertEquals("期望的页面为：" + exceptedActivity + "实际为："
							+ currentActivity, exceptedActivity,
							currentActivity);
				} else {
					logger.error("星座控件未显示！");
				}
				// logger.error("星座控件没显示", new NoSuchElementException());
			}

		} else {
			logger.info("未显示黄历控件");
		}
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	// 星座详情界面，点击右侧按钮，在弹出的12星座中选择任意星座
	//
	// 1、星座详情界面显示为选择后的星座信息
	//
	// 2、返回到主界面，主界面显示为切换后的星座及星座信息
	@Test
	public void testHoroscopeDetailpageChange() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isCalendarScreenDisplayed = false;
		try {
			isCalendarScreenDisplayed = app.mainScreen().calendarScreen
					.isDisplayed();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		AndroidElement calendarScreen = null;
		if (isCalendarScreenDisplayed) {
			// 滑动日历控件
			calendarScreen = app.mainScreen().calendarScreen;
			// app.mainScreen().swipeWidget2Up(calendarScreen, "日历控件", 500);
			as.swipeWidget2Up((AndroidDriver<?>) driver, calendarScreen, 500);
		} else {

			isCalendarScreenDisplayed = as.waitElentAndCapture(
					app.mainScreen().calendarScreen, "日历控件未找到");
			if (isCalendarScreenDisplayed) {
				calendarScreen = app.mainScreen().calendarScreen;
				as.swipeWidget2Up((AndroidDriver<?>) driver, calendarScreen,
						500);
			}

		}

		boolean isAlmanac = false;
		isAlmanac = as.waitElentAndCapture(app.mainScreen().almanacWidget,
				"黄历控件未显示");
		AndroidElement AlmanacWidget;
		if (isAlmanac) {
			AlmanacWidget = app.mainScreen().almanacWidget;
			// 滑动黄历控件
			// app.mainScreen().swipeWidget2Up(AlmanacWidget, "黄历历控件", 500);
			as.swipeWidget2Up((AndroidDriver<?>) driver, AlmanacWidget, 100);
			boolean isHoroDlp = false;
			isHoroDlp = as.waitElentAndCapture(
					app.mainScreen().horoscopeWidget, "定位星座控件失败");
			AndroidElement horoWidget = null;
			if (isHoroDlp) {
				horoWidget = app.mainScreen().horoscopeWidget;
				horoWidget.click();
			} else {
				logger.info("正在等待星座控件显示...");
				isHoroDlp = as.waitElentAndCapture(horoWidget, "星座控件未显示");
				if (isHoroDlp) {
					horoWidget = app.mainScreen().horoscopeWidget;
					horoWidget.click();

				} else {
					logger.error("星座控件未显示！");
				}
				// logger.error("星座控件没显示", new NoSuchElementException());
			}

		} else {
			logger.info("未显示黄历控件");
		}

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		boolean isChageButtonDisplay = false;
		isChageButtonDisplay = as.waitElentAndCapture(app.horoscopeScreen()
				.getChangeButton(), "等待星座切换按钮");
		if (isChageButtonDisplay) {
			app.horoscopeScreen().getChangeButton().click();
		}

		logger.info(app.horoscopeScreen().getScopeCard12().size());
		int x1 = 0;
		int y1 = 0;
		try {
			x1 = app.horoscopeScreen().getHoro12(horoScope[scopeIndex]).x;
			y1 = app.horoscopeScreen().getHoro12(horoScope[scopeIndex]).y;
		} catch (Exception e2) {
			// TODO 自动生成的 catch 块
			e2.printStackTrace();
		}

		TouchAction ta = new TouchAction(driver);
		logger.info("点击的星座坐标为：" + "x=" + x1 + "y=" + y1);
		ta.tap(x1, y1).perform();
		// 获取星座页面的星座日期
		boolean ishoroScopeDis = false;
		ishoroScopeDis = as.waitElentAndCapture(
				app.horoscopeScreen().scopeDate, "没有找到星座插件");
		String scopeScreenDate = null;
		if (ishoroScopeDis) {
			scopeScreenDate = app.horoscopeScreen().scopeDate.getText();
		} else {
			as.takeScreenShot("星座控件未显示");
		}

		logger.info("星座页面的星座日期为：" + scopeScreenDate);
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}

		boolean ismainScreenScopeDateDisplay = false;
		ismainScreenScopeDateDisplay = as.waitElentAndCapture(app.mainScreen()
				.getMainScrennScopeName(), "未获取到星座控件");
		if (ismainScreenScopeDateDisplay) {
			// 获取主界面的星座日期
			String scopeMainScreenDate = app.mainScreen()
					.getMainScrennScopeName().getText();
			logger.info("主页面的星座日期为：" + scopeMainScreenDate);
			Assert.assertEquals("期望星座日期为：" + scopeScreenDate + "实际星座日期为："
					+ scopeMainScreenDate, scopeScreenDate, scopeMainScreenDate);
		} else {
			logger.info("当前页面没有显示星座插件正在查找...");
			boolean isAlmanac1 = false;

			isAlmanac1 = as.waitElentAndCapture(app.mainScreen().almanacWidget,
					"黄历未显示");

			AndroidElement AlmanacWidget1;
			if (isAlmanac1) {
				AlmanacWidget1 = app.mainScreen().almanacWidget;
				// 滑动黄历控件
				// app.mainScreen().swipeWidget2Up(AlmanacWidget1, "黄历历控件",
				// 500);
				as.swipeWidget2Up((AndroidDriver<?>) driver, AlmanacWidget1,
						500);

				boolean isHoroDlp = false;
				isHoroDlp = as.waitElentAndCapture(
						app.mainScreen().horoscopeWidget, "定位星座控件失败");

				int i = 0;
				while (!isHoroDlp) {
					logger.info("滑动不到位,正在继续滑动...当前尝试第" + (i + 1) + "次");
					as.swipeWidget2Up((AndroidDriver<?>) driver,
							AlmanacWidget1, 500);

					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}

					isHoroDlp = app.mainScreen().isWidgetDisplay(
							app.mainScreen().horoscopeWidget);
					if (i == 10) {
						logger.info("尝试10次无果...");
						break;
					}
					if (isHoroDlp) {
						break;
					}

					i++;
				}

				AndroidElement horoWidget = null;
				if (isHoroDlp) {
					horoWidget = app.mainScreen().horoscopeWidget;
					horoWidget.click();
					boolean isscopeMainScreenDate = false;
					isscopeMainScreenDate = as
							.waitElentAndCapture(app.mainScreen()
									.getMainScrennScopeName(), "没有查找到星座日期");
					String scopeMainScreenDate = null;
					if (isscopeMainScreenDate) {

						scopeMainScreenDate = app.mainScreen()
								.getMainScrennScopeName().getText();
					} else {
						logger.error("没有查找到主界面星座,正在截图...");
						as.takeScreenShot("没有查找到主界面星座");
					}

					logger.info("主页面的星座日期为：" + scopeMainScreenDate);
					Assert.assertEquals("期望星座日期为：" + scopeScreenDate
							+ "实际星座日期为：" + scopeMainScreenDate,
							scopeScreenDate, scopeMainScreenDate);
				}
			}

			try {
				Thread.sleep(15000);
			} catch (InterruptedException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}
