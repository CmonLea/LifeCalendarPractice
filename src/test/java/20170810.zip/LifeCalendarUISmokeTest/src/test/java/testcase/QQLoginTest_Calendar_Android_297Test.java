package testcase;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;

import rule.TestName;
import screen.AbstractScreen;
import util.ScreenRecorder;
//@Ignore
//实现登录操作并判断是否登录成功
public class QQLoginTest_Calendar_Android_297Test extends AbstractTest {
	public static Logger logger = Logger
			.getLogger(WBLoginTest_Calendar_Android_297Test.class);

	@Rule
	public TestName name =new TestName();
	@Before
	public void setUp() {
		boolean isqqInstalled = false;// 假设QQ默认没有安装
		// 判断QQ是否安装，安装则将判断参数设置为true
		isqqInstalled = driver.isAppInstalled("com.tencent.mobileqq");
		
		logger.info("isqqInstalled:"+isqqInstalled);
		if (isqqInstalled) {
			logger.info("手机上存在QQ客户端正在卸载QQ客户端...");
			driver.removeApp("com.tencent.mobileqq");
			if (!isqqInstalled) {
				logger.info("卸载QQ客户端成功！");
			}
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}else{
			logger.info("手机没有安装QQ...");
		}
		

		boolean alertWindow = false;// 权限提示框
		try {
			alertWindow = app.permissionScreen().alertWindow.isDisplayed();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (alertWindow) {
			app.permissionScreen().allow.click();// 运行获取权限
		}

		app.mainScreen().myPageTag.click();
		if (app.myScreen().isLogin()) {
			app.myScreen().enterLogOutPage();// 进入退出登录页面
			app.personalCenterScreen().logOut();// 退出登录
		}

	}

	@Test(timeout = 120000)
	public void testQQLogin() {
		
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		app.mainScreen().myPageTag.click();

		app.myScreen().enterLoginPage();

		app.loginScreen().qqLogin("2187176501", "Test2017");

		AbstractScreen as = new AbstractScreen(driver);
		boolean isInitUserNameDisplay = false;
		isInitUserNameDisplay = as.waitElentAndCapture(
				app.myScreen().initUserName, "登录用户名没显示");
		if (isInitUserNameDisplay) {
			String exceptedName = app.myScreen().initUserName.getText();

			assertEquals("期望值：MobileTest" + "实际值为:" + exceptedName,
					app.myScreen().initUserName.getText(), "MobileTest");

		}else{
			logger.info("可能出现了验证界面");
			as.takeScreenShot("查找登录后页面失败");
		}
		try {
		ScreenRecorder.StopScreenRecording(name.getMethodName(),
				"recordFolder", true);
	} catch (IOException e) {
		// TODO 自动生成的 catch 块
		e.printStackTrace();
	} catch (InterruptedException e) {
		// TODO 自动生成的 catch 块
		e.printStackTrace();
	}
	}

}