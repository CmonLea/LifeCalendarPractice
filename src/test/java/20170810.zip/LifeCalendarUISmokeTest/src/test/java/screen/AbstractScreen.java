package screen;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ScreenshotState;
import io.appium.java_client.SwipeElementDirection;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ScreenshotState.ResizeMode;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.StartsActivity;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import testcase.AbstractTest;

public class AbstractScreen {
	public static Logger logger = Logger.getLogger(AbstractScreen.class);
	protected AppiumDriver<?> driver;
	File file = new File("screenShotCapture.jpg");// 未处理的截图
	File outImageFile = new File("processedScreenshot.jpg");// 处理过的截图

	// static Logger logger = Logger.getLogger(AbstractScreen.class.getName());

	// 初始化Page Object对象
	public AbstractScreen(AppiumDriver<?> driver) {
		this.driver = driver;

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	/**
	 * 公用方法查找元素并等待
	 * 
	 * @param by
	 * @param timeOutInSeconds
	 * @return
	 */
	public MobileElement findElementWithTimeout(By by, int timeOutInSeconds) {
		return (MobileElement) (new WebDriverWait(driver, timeOutInSeconds))
				.until(ExpectedConditions.presenceOfElementLocated(by));
	}

	public WebElement findElementWithTimeout(WebElement we) {

		// Waiting 30 seconds for an element to be present on the page, checking
		// for its presence once every 5 seconds.
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		return wait.until(ExpectedConditions.visibilityOf(we));
	}

	@SuppressWarnings("unchecked")
	public List<WebElement> findElementsWithTimeout(By by, int timeOutInSeconds) {
		return (List<WebElement>) (new WebDriverWait(driver, timeOutInSeconds))
				.until(ExpectedConditions.presenceOfElementLocated(by));
	}

	public void resetAPP() {
		logger.info("重置APP...");
		driver.resetApp();
		Activity ac = new Activity("com.updrv.lifecalendar",
				".activity.MainActivity");
		((StartsActivity) driver).startActivity(ac);
	}

	/**
	 * @此方法用于截图
	 * 
	 * @param drivername
	 *            Appium Driver 实例
	 * @param filename
	 *            截图文件名称
	 */
	// 截图操作
	public void takeScreenShot(String filename) {
		// PropertyConfigurator.configure("log4j.properties");
		logger.info("开始截图...");
		// 存取截图文件的目录
		String destDir = "screenshots";
		// 截图文件
		File scrFile = null;
		try {
			if (driver != null) {
				scrFile = driver.getScreenshotAs(OutputType.FILE);
			} else {

				this.driver = AbstractTest.driver;
				scrFile = driver.getScreenshotAs(OutputType.FILE);
			}

		} catch (WebDriverException e1) {
			logger.error("出现了异常！");
			e1.printStackTrace();
		}

		// 日期格式
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss");
		// 创建截图目录
		new File(destDir).mkdirs();
		// 存取的截图文件命名
		String destFile = dateFormat.format(new Date()) + filename + ".png";
		// 截图存放的路径
		File destFilePath = new File(destDir + "/" + destFile);
		String destFolder = destFilePath.getAbsolutePath();
		try {
			logger.info("截图位于:" + destDir + "/" + destFile);
			if (scrFile != null) {
				// 防止带空格的路径拷贝失败
				FileUtils.copyFile(scrFile, new File("\"" + destFolder + "\""));
			} else {
				logger.equals("发生了未知异常...");
			}

		} catch (IOException e) {
			logger.info("截图失败");
			e.printStackTrace();
		}
	}

	/**
	 * @此方法用于比较2张图片的相似度
	 * @param templatePicture
	 *            用于比较的模板图片
	 * @param actualPicture
	 *            待比较的图片
	 * @param sc
	 *            double类型，表示相似度， 相似度数值范围在 (-1.0, 1.0). 返回1.0表示两张图片为同一张图片
	 * @return isSimilar表示图片是否匹配
	 * @throws IOException
	 */
	public boolean testPictureSimilarity(BufferedImage actualPicture,
			BufferedImage templatePicture) throws IOException {
		PropertyConfigurator.configure("log4j2.properties");
		boolean isSimilar = false;
		// WebElement element = null;
		templatePicture = ImageIO.read(file);
		// actualPicture = getCustomeScreenshots(element);
		actualPicture = ImageIO.read(outImageFile);
		double sc = ScreenshotState.getOverlapScore(actualPicture,
				templatePicture, ResizeMode.TEMPLATE_TO_REFERENCE_RESOLUTION);

		logger.info("sc=" + sc);
		if (sc == 1.0) {
			isSimilar = true;
		}
		return isSimilar;

	}

	/**
	 * 此方法用于获取自定义区域截图
	 * 
	 * @param element
	 *            需要截取的元素
	 * @return BufferedImage类型的截图
	 * @throws IOException
	 */
	public BufferedImage getCustomeScreenshots(WebElement element)
			throws IOException {
		PropertyConfigurator.configure("log4j2.properties");
		// 将图片写入到文件
		// File file = new File("screenShotCapture.jpg");//未处理的截图
		// File outImageFile = new File("processedScreenshot.jpg");//处理过的截图

		// 实现截图功能
		final byte[] srcImage = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.BYTES);
		// 创建输出流将截图写到文件里
		FileOutputStream fis = new FileOutputStream(file);
		BufferedOutputStream bos = new BufferedOutputStream(fis);
		try {
			bos.write(srcImage);
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (bos != null) {
			bos.close();
		}

		// 需要截取的元素
		// element =
		// driver.findElement(By.className("android.widget.TextView"));

		// 获取需要截图图片的坐标和尺寸
		final Point elementLocation = element.getLocation();
		logger.info("elementLocation.x=" + elementLocation.x);
		logger.info("elementLocation.y=" + elementLocation.y);
		final Dimension elementSize = element.getSize();
		logger.info("elementSize.x=" + elementSize.getHeight());
		logger.info("elementSize.y=" + elementSize.getWidth());

		// 从读入的文件来截取图片
		final BufferedImage screenshot = ImageIO.read(file);
		// 执行二次截图操作
		BufferedImage processedScreenshot = screenshot.getSubimage(
				elementLocation.x, elementLocation.y, elementSize.width,
				elementSize.height);
		// 将截取的图片写入到新文件
		ImageIO.write(processedScreenshot, "jpg", outImageFile);

		return ImageIO.read(outImageFile);

	}

	/**
	 * 循环等待定位控件出现，如果30次还没出现就截图并返回false
	 * 
	 * @param we
	 *            需要查找的控件
	 * @param fileName
	 *            截图名称
	 * @return false 控件未查找到时返回
	 */
	public boolean waitElentAndCapture(WebElement we, String fileName) {
		// PropertyConfigurator.configure("log4j2.properties");
		// WebElement we = null;
		// 判断该控件是否存在
		// WebElement web = null;

		boolean isElementDisplayed = false;
		try {
			// 判断初始状态要查找的控件是否显示
			if (we != null) {
				try {
					isElementDisplayed = we.isDisplayed();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				if (isElementDisplayed) {

					logger.info(we + "元素已显示执行下一步操作");
					return isElementDisplayed;
				}

			} else {
				logger.info("元素没有显示正在执行查找...");
				int i = 0;
				// 如果没有显示则循环查找
				while (!isElementDisplayed && i < 30) {

					try {
						logger.info("正在等待页面出现..." + (i + 1)/2 + "秒");
						Thread.sleep(500);
						// 等待后再次查看控件是否显示
						try {
							isElementDisplayed = we.isDisplayed();
						} catch (Exception e) {

							e.printStackTrace();
						}
						if (isElementDisplayed) {
							logger.info("查找到控件...");

							return isElementDisplayed;
						}
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					if (i == 29) {
						logger.info("已达到最大查找次数，未获取到查找元素正在截图...");
						takeScreenShot(fileName);
						break;
					}

					i++;
				}

			}

		} catch (Exception e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}

		return isElementDisplayed;
	}

	/**
	 * 判断元素是否显示
	 * 
	 * @param we
	 * @return
	 */
	protected boolean isElementDisplayed(WebElement we) {
		boolean isElementDisplayed = false;
		logger.info("假设控件默认未显示..." + isElementDisplayed);

		if (we.isDisplayed()) {
			isElementDisplayed = true;
			logger.info("如果控件显示则将控件置为true,isElementDisplayed="
					+ isElementDisplayed);
		} else {
			waitElentAndCapture(we, we + "控件未显示");
		}
		logger.info("返回最后的值,isElementDisplayed=" + isElementDisplayed);
		return isElementDisplayed;

	}

	public boolean isWidgetDisplay(AndroidElement androidElement) {
		boolean isWidgetDisplay = false;

		// isWidgetDisplay = waitElentAndCapture(androidElement,
		// "查找"+androidElement.toString()+"控件失败");
		try {
			isWidgetDisplay = androidElement.isDisplayed();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (isWidgetDisplay) {
			return true;
		}

		else {
			return false;
		}

	}

	/**
	 * 
	 * @param androidWidgit
	 *            Android控件
	 * @param widgetName
	 *            控件名称
	 */
	@SuppressWarnings("deprecation")
	// public void swipeWidget2Up(AndroidElement androidWidgit, String
	// widgetName,
	// int duration) {
	// logger.info("滑动" + widgetName + "...");
	// boolean isWidgetDisplay = false;
	//
	// isWidgetDisplay = isWidgetDisplay(androidWidgit);
	// if (isWidgetDisplay) {
	// androidWidgit.swipe(SwipeElementDirection.UP, duration);
	// logger.info(widgetName + "滑动完毕...");
	// } else {
	// boolean wait = waitElentAndCapture(androidWidgit, "查找日历控件"
	// + widgetName + "失败");
	// if (wait) {
	// androidWidgit.swipe(SwipeElementDirection.UP, duration);
	// logger.info(widgetName + "滑动完毕...");
	// } else {
	// // Throwable NoSuchElementException = null;
	// logger.error("没有查找到" + widgetName);
	// }
	//
	// }
	//
	// }
	/**
	 * 此方法用于向上滑动控件
	 * @param driver
	 *            AndroidDriver 实例
	 * @param androidWidgit
	 *            要滑动的控件
	 * @param duration
	 *            滑动的时间
	 */
	public void swipeWidget2Up(AndroidDriver<?> driver,
			AndroidElement androidWidgit, int duration) {
		logger.info("滑动" + androidWidgit + "...");
		boolean isWidgetDisplay = false;

		int startx = androidWidgit.getCenter().getX();
		int endx = androidWidgit.getCenter().getX();
		int starty = androidWidgit.getSize().getHeight()
				+ androidWidgit.getLocation().getY() - 1;
		int endy = androidWidgit.getLocation().getY() + 1;

		isWidgetDisplay = isWidgetDisplay(androidWidgit);
		if (isWidgetDisplay) {
			driver.swipe(startx, starty, endx, endy, duration);
			logger.info(androidWidgit + "滑动完毕...");
		} else {
			boolean wait = waitElentAndCapture(androidWidgit, "查找日历控件"
					+ androidWidgit + "失败");
			if (wait) {

				driver.swipe(startx, starty, endx, endy, duration);
				logger.info(androidWidgit + "滑动完毕...");
			} else {
				// Throwable NoSuchElementException = null;
				logger.error("没有查找到" + androidWidgit);
			}

		}

	}

	/**
	 * 此方法用于向上滑动控件
	 * 
	 * @param driver
	 *            AndroidDriver 实例
	 * @param androidWidgit
	 *            要滑动的控件
	 * @param duration
	 *            滑动的时间
	 */
	public void swipeWidget2Left(AndroidDriver<?> driver,
			AndroidElement androidWidgit, int duration) {
		logger.info("滑动" + androidWidgit + "...");
		boolean isWidgetDisplay = false;

		int startx = androidWidgit.getLocation().getX()
				+ androidWidgit.getSize().width;

		int endx = androidWidgit.getLocation().getX();
		int starty = androidWidgit.getCenter().getY();

		int endy = starty;

		isWidgetDisplay = isWidgetDisplay(androidWidgit);
		if (isWidgetDisplay) {
			driver.swipe(startx-10, starty, endx+10, endy, duration);
			logger.info(androidWidgit + "滑动完毕...");
		} else {
			boolean wait = waitElentAndCapture(androidWidgit, "查找日历控件"
					+ androidWidgit + "失败");
			if (wait) {

				driver.swipe(startx-1, starty+1, endx, endy, duration);
				logger.info(androidWidgit + "滑动完毕...");
			} else {
				// Throwable NoSuchElementException = null;
				logger.error("没有查找到" + androidWidgit);
			}

		}

	}

	/**
	 * 封装滑动方法
	 * 
	 * @param firstElement
	 * @param lastElement
	 */
	public void swipeAndroidElement(AndroidElement firstElement,
			AndroidElement lastElement, int Derection) {
		// firstElment = historyList.get(0);// 获取历史今天列表第一条数据控件
		//
		// lastElement = historyList.get(historyInfoListLength - 1);//
		// 获取历史今天列表中倒数第一个元素
		// 方法1：能够正常滑动
		Point location1 = firstElement.getLocation();// 获取控件左上角的坐标
		Point center1 = firstElement.getCenter();// 获取控件中心的坐标

		Point location2 = lastElement.getLocation();
		Point center2 = lastElement.getCenter();
		TouchAction swipe = new TouchAction(driver);
		switch (Derection) {
		// 向上滑动

		case 0:

			swipe.press(lastElement, center1.x, center2.y - location2.y)
					.waitAction(Duration.ofMillis(500))
					.moveTo(firstElement, center1.x, center1.y - location1.y)
					.release();
			logger.info("开始滑动,从：" + center1.x + "," + (center2.y - location2.y)
					+ "滑动到：" + center1.x + "," + (center1.y - location1.y));
			swipe.perform();
			logger.info("滑动成功！");

			// 向下滑动
		case 1:
			swipe.press(firstElement, center1.x, center1.y - location1.y)
					.waitAction(Duration.ofMillis(500))
					.moveTo(lastElement, center1.x, center2.y - location2.y)

					.release();
			logger.info("开始滑动,从：" + center1.x + "," + (center2.y - location2.y)
					+ "滑动到：" + center1.x + "," + (center1.y - location1.y));
			swipe.perform();
			logger.info("滑动成功！");

		}

	}

	/**
	 * 
	 * @param androidWidgit
	 *            需要滑动的控件
	 */
	public void swipe2UpForFail(AndroidElement androidWidgit) {

		int x = androidWidgit.getCenter().x;
		int y = androidWidgit.getLocation().y;

		// int x1 = androidWidgit.getLocation().x;
		int y1 = androidWidgit.getLocation().y
				+ androidWidgit.getSize().getHeight();

		TouchAction ta = new TouchAction(driver);
		try {
			ta.longPress(x, y1 - 50).moveTo(x, y).release().perform();
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

		logger.info("从x=" + x + "y=" + y1 + "滑动到" + "x=" + x + "y=" + y);
	}

	/**
	 * 获取控件中心坐标
	 */
	public Point getElementCenterPoint(AndroidElement we) {
		int x = we.getLocation().x;// 获取控件的x坐标
		int y = we.getLocation().y;// 获取控件的y坐标
		int height = we.getSize().height;// 获取控件的高度
		int width = we.getSize().width;// 获取控件的宽度
		logger.info("中心点的坐标为：" + "x=" + (x + width / 2) + "," + "y="
				+ (y + height / 2));
		Point p = new Point((x + width / 2), (y + height / 2));
		return p;

	}

	/**
	 * 比较两个日期的大小
	 * 
	 * @param DATE1
	 *            待比较的日期1
	 * @param DATE2待比较的日期2
	 * @return
	 */
	public static int compare_date(String DATE1, String DATE2) {
		// 匹配"yyyy年mm月"格式的日期

		String regexDate = "\\d{4}年\\d{2}月";
		DateFormat df = null;
		if (DATE1.trim().matches(regexDate) && DATE2.trim().matches(regexDate)) {

			logger.info("输入的日期格式为：yyyy年MM月");
			df = new SimpleDateFormat("yyyy年MM月");
		} else {
			logger.info("输入日期格式为：yyyy-mm-dd HH : mm");
			df = new SimpleDateFormat("yyyy-MM-dd HH : mm");

		}

		try {

			Date dt1 = df.parse(DATE1);
			Date dt2 = df.parse(DATE2);
			if (dt1.getTime() > dt2.getTime()) {
				// logger.info("dt1:" + dt1.getTime() + "在dt2:"
				// + dt2.getTime() + "后");
				logger.info("dt1:" + DATE1 + "在dt2:" + DATE2 + "后");
				return 1;
			} else if (dt1.before(dt2)) {
				logger.info("dt1:" + dt1.getTime() + "在dt2:" + dt2.getTime()
						+ "前");
				logger.info("dt1:" + DATE1 + "在dt2:" + DATE2 + "前");
				return -1;
			} else {
				return 0;
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return 0;
	}

	/**
	 * 当进不下去的时候，使用该方法，例如可能是出现了一些对话框遮挡，该方法会把对话框干掉
	 */
	protected void SolveProblems() {
		// ....
	}

	// public void solveUpdateWindow(){
	// isElementDisplayed()
	// }

}