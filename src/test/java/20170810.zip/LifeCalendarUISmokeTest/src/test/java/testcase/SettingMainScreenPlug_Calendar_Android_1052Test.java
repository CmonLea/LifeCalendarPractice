package testcase;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import rule.TestName;
import screen.AbstractScreen;
import testcase.AbstractTest;
import util.ScreenRecorder;

//@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SettingMainScreenPlug_Calendar_Android_1052Test extends
		AbstractTest {
	private static Logger logger = Logger
			.getLogger(SettingMainScreenPlug_Calendar_Android_1052Test.class);

	AbstractScreen as = new AbstractScreen(driver);

	@Rule
	public TestName name = new TestName();

	@Before
	public void setup() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		// 如果弹升级框就点掉

		boolean isUpdateWindowDisplay = false;
		isUpdateWindowDisplay = as.waitElentAndCapture(app.mainScreen()
				.getUpdateWindow(), "升级框截图");

		// 点掉升级框
		if (isUpdateWindowDisplay) {
			logger.info("检测到有升级框弹出，正在解除障碍！");
			boolean isCancelButtonDisplay = false;
			isCancelButtonDisplay = as.waitElentAndCapture(app.mainScreen()
					.getUpdateCancelbutton(), "等待取消按钮显示");
			if (isCancelButtonDisplay) {
				app.mainScreen().getUpdateCancelbutton().click();
				logger.info("KO升级框！Perfect！");
			}

		}
		// 没有显示则循环查找升级框，查找10s后确实没显示即真的没有显示升级框往下操作
		int i = 1;
		while (!isUpdateWindowDisplay) {
			try {
				// 休眠1s钟查看是否显示
				logger.info("暂时没有显示升级框正在休眠" + i/2 + "秒等待升级框显示...");
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
			// 再次查看是否显示
			isUpdateWindowDisplay = as.waitElentAndCapture(app.mainScreen()
					.getUpdateWindow(), "升级框截图");
			// 点掉升级框
			if (isUpdateWindowDisplay) {
				logger.info("检测到有升级框弹出，正在解除障碍！");
				boolean isCancelButtonDisplay = false;
				isCancelButtonDisplay = as.waitElentAndCapture(app.mainScreen()
						.getUpdateCancelbutton(), "等待取消按钮显示");
				if (isCancelButtonDisplay) {
					app.mainScreen().getUpdateCancelbutton().click();
					logger.info("KO升级框！Perfect！");
				}
				break;
			}

			if (i == 10) {
				logger.info("等待了" + i/2 + "秒没有显示升级框！");
				break;
			}
			i++;
		}

	}

	// 默认顺序：记事、黄历、天气、星座、历史上的今天
	// 步骤：
	// 进入我的-系统设置-主页插件显示，在可显示的模块中，按住缩略图拖动
	//
	// 期望：
	// 1、可以调节模块的排序
	//
	// 2、主界面按调整的设置的排序正常显示
	//
	// 3、主界面插件功能正常
	@Test
	// @Ignore
	public void test1ChangePositon() {

		AndroidElement androidWidgit = app.mainScreen().calendarScreen;

		//app.mainScreen().swipeWidget2Up(androidWidgit, "日历控件", 500);
		as.swipeWidget2Up((AndroidDriver<?>)driver, androidWidgit, 500);
		// boolean isWeatherDisplay
		boolean isalmancWidget = false;
		isalmancWidget = as.waitElentAndCapture(app.mainScreen().almanacWidget,
				"没找到黄历插件");
		int almancy = 0;
		if (isalmancWidget) {
			almancy = app.mainScreen().almanacWidget.getLocation().y;
		}

		boolean isWeatherDisplay = false;
		isWeatherDisplay = as.waitElentAndCapture(
				app.mainScreen().weatherWidget, "没找到天气插件");
		int weathery = 0;
		if (isWeatherDisplay) {
			weathery = app.mainScreen().weatherWidget.getLocation().y;
		}

		logger.info("黄历的坐标为： " + almancy + " " + "天气的坐标为： " + weathery);
		logger.info("验证天气和黄历置换前的位置信息...");
		boolean isWeatherAfterAlmanc = weathery - almancy > 0 ? true : false;
		if (isWeatherAfterAlmanc) {
			Assert.assertTrue("置换前天气在黄历下面为true,实际为：" + isWeatherAfterAlmanc,
					isWeatherAfterAlmanc);
			logger.info("验证天气和黄历置换前的位置信息完毕...");
		} else {
			logger.info("正在截图...");
		}

		app.mainScreen().myPageTag.click();

		app.myScreen().getSystemSetting().click();
		// 点击系统设置页面的首页信息显示与排序设置
		app.systemSettingScreen().getMainPagePlugSetting().click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		// 黄历和天气交换位置
		app.mainpageInfoSettingScreen().getPlugPostion(5);
		// 按返回键返回到初始操作页面
		app.mainpageInfoSettingScreen().getBackBtn().click();
		// ((AndroidDriver<?>)driver).pressKeyCode(AndroidKeyCode.BACK);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);

		// 查看首页是否交换成功
		boolean isMypageTagDispaly = false;
		isMypageTagDispaly = as.waitElentAndCapture(
				app.mainScreen().homePageTag, "查找我的标签");
		if (isMypageTagDispaly) {
			app.mainScreen().homePageTag.click();
		}

		// 黄历控件
		AndroidElement androidWidgit_after = app.mainScreen().calendarScreen;

		//app.mainScreen().swipeWidget2Up(androidWidgit_after, "日历控件", 500);
		as.swipeWidget2Up((AndroidDriver<?>) driver, androidWidgit_after, 500);
		
		// boolean isWeatherDisplay
		boolean isAlmancWidis = false;
		isAlmancWidis = as.waitElentAndCapture(app.mainScreen().almanacWidget,
				"没有找到黄历插件");
		if (isAlmancWidis) {
			int almancy1 = app.mainScreen().almanacWidget.getLocation().y;
			int weathery1 = app.mainScreen().weatherWidget.getLocation().y;
			logger.info("验证天气和黄历置换后的位置信息...");
			boolean isWeatherBeforeAlman = weathery1 - almancy1 < 0 ? true
					: false;
			Assert.assertTrue("置换后黄历在天气下面为true,实际为：" + isWeatherBeforeAlman,
					isWeatherBeforeAlman);
			logger.info("验证天气和黄历置换后的位置信息完毕...");
		}
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	//
	// 步骤：
	// 点击任意模块右上角的×按钮，返回主界面
	//
	// 期望：
	// 模块显示在下方不显示模块列表中
	//
	// 删除的模块不会显示在主界面

	@Test
	// @Ignore
	public void test2DeletePlug() {
		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isMyPageTagDispaly = false;
		isMyPageTagDispaly = as.waitElentAndCapture(app.mainScreen().myPageTag,
				"我的标签未显示");
		if (isMyPageTagDispaly) {
			app.mainScreen().myPageTag.click();
		}
		// 点击我的页面系统设置
		boolean isSystemSetDispaly = false;
		isSystemSetDispaly = as.waitElentAndCapture(app.myScreen()
				.getSystemSetting(), "系统设置页面未显示");
		if (isSystemSetDispaly) {
			app.myScreen().getSystemSetting().click();
		}

		// 进入插件设置页面
		boolean isPlugSettingDispaly = false;
		isPlugSettingDispaly = as.waitElentAndCapture(app.systemSettingScreen()
				.getMainPagePlugSetting(), "插件设置没有显示");
		if (isPlugSettingDispaly) {
			app.systemSettingScreen().getMainPagePlugSetting().click();
		}

		// 删掉黄历
		boolean isPlugDeleteAlma = false;
		isPlugDeleteAlma = as.waitElentAndCapture(app
				.mainpageInfoSettingScreen().getPlugDeleteBtn().get(1),
				"删除按钮未显示");
		if (isPlugDeleteAlma) {
			app.mainpageInfoSettingScreen().getPlugDeleteBtn().get(1).click();
		}

		// 验证是否放到了不显示的模块中
		logger.info("验证是否显示到了不显示的模块中...");

		AndroidElement androidWidgit = app.mainpageInfoSettingScreen()
				.getPlugImage().get(2);
	//	as.swipeWidget2Up(androidWidgit, "滑动第二个插件", 500);
		as.swipeWidget2Up((AndroidDriver<?>) driver, androidWidgit, 0);

		boolean isNotDisplayAreaView = false;
		isNotDisplayAreaView = as.isWidgetDisplay(androidWidgit);
		if (isNotDisplayAreaView) {
			logger.info("正在验证是否显示了不显示模块..");
			Assert.assertTrue("期望显示不显示的模块栏目为true,实际为" + isNotDisplayAreaView,
					isNotDisplayAreaView);
			logger.info("验证是否显示了不显示模块完毕..");
		}
		// 按返回键返回到初始操作页面
		app.mainpageInfoSettingScreen().getBackBtn().click();
		// ((AndroidDriver<?>)driver).pressKeyCode(AndroidKeyCode.BACK);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);

		// 返回到首页查看是否存在删除的控件
		app.mainScreen().homePageTag.click();
//
//		app.mainScreen().swipeWidget2Up(app.mainScreen().calendarScreen,
//				"滑动日历", 500);
		as.swipeWidget2Up((AndroidDriver<?>) driver, app.mainScreen().calendarScreen, 0);
		boolean isAlmanacDisplay = false;
		isAlmanacDisplay = as.isWidgetDisplay(app.mainScreen().almanacWidget);
		// Assert.assertTrue("期望不显示黄历控件为true,实际为："+isAlmanacDisplay,
		// !isAlmanacDisplay);
		Assert.assertFalse("期望不显示黄历控件为true,实际为：" + isAlmanacDisplay,
				isAlmanacDisplay);

		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

	// 步骤：
	// 点击不显示模块中任意模块
	//
	// 返回主界面

	// 期望：
	// 恢复模块显示在可拖动列表中
	//
	// 所选的模块可正常恢复
	@Test(timeout = 1000 * 90)
	// @Ignore// 发现目前有依赖上条用例的情况可能会造成用例的失败,为了避免死循环加入超时设置
	public void test3RecoveryPlug() {

		try {
			ScreenRecorder.StartScreenRecording(name.getMethodName());
		} catch (IOException e1) {
			// TODO 自动生成的 catch 块
			e1.printStackTrace();
		}
		boolean isMyPageTagDispaly = false;
		isMyPageTagDispaly = as.waitElentAndCapture(app.mainScreen().myPageTag,
				"我的标签未显示");
		if (isMyPageTagDispaly) {
			app.mainScreen().myPageTag.click();
		}

		boolean isSystemSetDis = false;
		isSystemSetDis = as.waitElentAndCapture(app.myScreen()
				.getSystemSetting(), "系统设置选项没显示");
		if (isSystemSetDis) {
			app.myScreen().getSystemSetting().click();
		}
		boolean isMainPagePlugSetting = false;
		isMainPagePlugSetting = as.waitElentAndCapture(app
				.systemSettingScreen().getMainPagePlugSetting(), "系统设置插件页面未显示");
		if (isMainPagePlugSetting) {
			app.systemSettingScreen().getMainPagePlugSetting().click();
		}

		// 删掉黄历
		boolean isPlugDeleteBtnDispaly = false;
		isPlugDeleteBtnDispaly = as.waitElentAndCapture(app
				.mainpageInfoSettingScreen().getPlugDeleteBtn().get(1),
				"插件删除按钮未显示");
		if (isPlugDeleteBtnDispaly) {
			app.mainpageInfoSettingScreen().getPlugDeleteBtn().get(1).click();
		}

		TouchAction ta = new TouchAction(driver);
		// 滑动以显示删除了的模块
		logger.info("滑动以显示删除的模块完毕...");
		AndroidElement androidWidgit = app.mainpageInfoSettingScreen()
				.getPlugImage().get(2);

		boolean isNotDisplayAreaView = false;

		AndroidElement androidWidgit1 = app.mainpageInfoSettingScreen()
				.getNotDisplayWidgit();
		isNotDisplayAreaView = as.isWidgetDisplay(androidWidgit1);
		// 当没有显示不显示模块时就持续滑动直至显示了模块
		while (!isNotDisplayAreaView) {
			//as.swipeWidget2Up(androidWidgit, "滑动第二个插件", 500);
			as.swipeWidget2Up((AndroidDriver<?>) driver, androidWidgit, 500);
			// 每隔1s停止滑动检查一下是否滑动到了指定位置
			try {
				Thread.sleep(1000);
				logger.info("休眠1s检查是否滑动到指定位置...");

				isNotDisplayAreaView = as.isWidgetDisplay(androidWidgit1);
			} catch (InterruptedException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}

			if (isNotDisplayAreaView) {
				logger.info("已滑动到指定位置...查看是否显示了删除的控件");
				// 获取控件的坐标和屏幕的相对位置判断控件在屏幕的位置,主要是y轴坐标
				int y = androidWidgit1.getLocation().y
						+ androidWidgit1.getSize().getHeight();
				AndroidElement content = app.mainpageInfoSettingScreen()
						.getCotent();
				int contenty = content.getLocation().y
						+ content.getSize().height;
				logger.info("不显示模块的y坐标为：" + y + " " + "屏幕的y坐标为：" + contenty
						+ " " + "y/contenty=" + ((float) y / contenty));
				boolean elementLocation = ((float) y / contenty) > (0.75) ? true
						: false;
				logger.info("不显示模块的占比大于0.75为：" + elementLocation);
				while (elementLocation) {
					//as.swipeWidget2Up(androidWidgit, "滑动第二个插件", 500);
					as.swipeWidget2Up((AndroidDriver<?>) driver, androidWidgit, 500);
					// 每隔1s停止滑动检查一下是否滑动到了指定位置
					try {
						Thread.sleep(1000);
						logger.info("休眠1s检查是否滑动到指定位置...");

						// isNotDisplayAreaView =
						// as.isWidgetDisplay(androidWidgit1);

						y = androidWidgit1.getLocation().y
								+ androidWidgit1.getSize().getHeight();
						elementLocation = ((float) y / contenty) > (0.75) ? true
								: false;
						logger.info("不显示模块的y坐标为：" + y + " " + "屏幕的y坐标为："
								+ contenty + " " + "y/contenty="
								+ ((float) y / contenty));
					} catch (InterruptedException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					if (!elementLocation) {
						break;
					}

				}

			}

		}

		// 获取要点击的删除的控件的坐标
		int plugsize = app.mainpageInfoSettingScreen().getSinglePlug().size();

		AndroidElement deletePlug = app.mainpageInfoSettingScreen()
				.getSinglePlug().get(plugsize - 1);
		int deletePlugX = as.getElementCenterPoint(deletePlug).x;
		int delerePlugY = as.getElementCenterPoint(deletePlug).y;
		// 点击删除的控件恢复
		logger.info("点击删除的控件的坐标为：x=" + deletePlugX + "y=" + delerePlugY);
		// 注意要执行否则点击不会生效
		ta.tap(deletePlugX, delerePlugY).perform();

		// 再次滑动查看是否存在删除的控件

		androidWidgit = app.mainpageInfoSettingScreen().getNotDisplayWidgit();
		isNotDisplayAreaView = as.isWidgetDisplay(androidWidgit1);
		if (!isNotDisplayAreaView) {
			logger.info("正在验证是否没有显示不显示模块..");
			Assert.assertTrue("期望显示不显示的模块栏目为false,实际为" + isNotDisplayAreaView,
					!isNotDisplayAreaView);
			logger.info("验证是否显示了不显示模块完毕..");
		}

		// 按返回键返回到初始操作页面
		app.mainpageInfoSettingScreen().getBackBtn().click();
		// ((AndroidDriver<?>)driver).pressKeyCode(AndroidKeyCode.BACK);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		((AndroidDriver<?>) driver).pressKeyCode(AndroidKeyCode.BACK);

		// 返回到首页查看是否存在删除的控件,由于恢复后的插件是显示在最后一个位置
		app.mainScreen().homePageTag.click();
//
//		app.mainScreen().swipeWidget2Up(app.mainScreen().calendarScreen,
//				"滑动日历", 500);
		as.swipeWidget2Up((AndroidDriver<?>) driver, app.mainScreen().calendarScreen, 500);
		
//		app.mainScreen().swipeWidget2Up(app.mainScreen().weatherWidget, "滑动天气",
//				500);
		as.swipeWidget2Up((AndroidDriver<?>) driver, app.mainScreen().weatherWidget, 0);
		boolean isAdDisplay = false;
		isAdDisplay = as.isWidgetDisplay(app.mainScreen().advertisement);
		if (isAdDisplay) {
//			app.mainScreen().swipeWidget2Up(app.mainScreen().advertisement,
//					"滑动广告", 500);
			as.swipeWidget2Up((AndroidDriver<?>) driver, app.mainScreen().advertisement, 0);
		}
		// 星座控件是否显示
		boolean isHorsDisplay = false;
		isHorsDisplay = as.isWidgetDisplay(app.mainScreen().horoscopeWidget);
		if (isHorsDisplay) {
//			app.mainScreen().swipeWidget2Up(app.mainScreen().horoscopeWidget,
//					"滑动星座", 500);
			as.swipeWidget2Up((AndroidDriver<?>) driver, app.mainScreen().horoscopeWidget, 0);
		}

		boolean isAlmanacDisplay = false;
		isAlmanacDisplay = as.isWidgetDisplay(app.mainScreen().almanacWidget);

		Assert.assertTrue("期望显示黄历控件为true,实际为：" + isAlmanacDisplay,
				isAlmanacDisplay);
		try {
			ScreenRecorder.StopScreenRecording(name.getMethodName(),
					"recordFolder", true);
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}

	}

	@After
	public void tearDownPlug() {
		logger.info("正在清理测试环境...");
		try {
			Runtime.getRuntime().exec(
					"adb shell pm clear com.updrv.lifecalendar");

			try {
				Thread.sleep(10 * 1000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

}
