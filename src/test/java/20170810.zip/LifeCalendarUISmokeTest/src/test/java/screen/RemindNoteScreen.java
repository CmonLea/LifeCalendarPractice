package screen;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class RemindNoteScreen extends AbstractScreen {

	public RemindNoteScreen(AppiumDriver<?> driver) {
		super(driver);

	}

	// 提醒列表中每条提醒的提醒时间id
	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/tv_record_time")
	private List<AndroidElement> remindList;

	public List<AndroidElement> getRemindList() {
		return remindList;
	}

	// 设置5s延时
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/ll_note_back")
	private AndroidElement backButton;

	public AndroidElement getBackButton() {
		return backButton;
	}

	/**
	 * 获取提醒记事的提醒时间
	 * 
	 * @return
	 */
	public List<String> getRemindNoteListDate() {
		// 2018-07-19 14 : 06 (一次)
		Pattern regex = Pattern.compile("\\([\u4e00-\u9fa5]{1,5}\\)");
		// Iterator<WebElement> it = recordName.iterator();
		List<String> noteDates = new ArrayList<String>();
		// System.out.println(recordName.size());
		for (int i = 0; i < remindList.size(); i++) {
			// 输出匹配后的年月日
			logger.info(remindList.get(i).getText().split(regex.toString())[0]
					.trim());
			noteDates
					.add(remindList.get(i).getText().split(regex.toString())[0]
							.trim());

		}

		return noteDates;
	}
}
