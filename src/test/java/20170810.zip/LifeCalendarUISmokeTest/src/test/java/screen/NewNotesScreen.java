package screen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

public class NewNotesScreen extends AbstractScreen {

	public NewNotesScreen(AppiumDriver<?> driver) {
		super(driver);
	}

	// 新建记事页面记事标题输入框
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/et_recordthing_title")
	private AndroidElement recordthingTitle;

	public AndroidElement getRecordthingTitle() {
		return recordthingTitle;
	}

	public AndroidElement getRecordthingSave() {
		return recordthingSave;
	}

	//
	// 新建记事页面保存记事按钮
	@WithTimeout(time = 5, unit = TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/save")
	private AndroidElement recordthingSave;

}
