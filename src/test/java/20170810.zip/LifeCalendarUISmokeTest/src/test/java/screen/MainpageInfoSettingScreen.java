package screen;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.WithTimeout;

/*
 * 首页信息设置页面
 */
public class MainpageInfoSettingScreen extends AbstractScreen {

	public MainpageInfoSettingScreen(AppiumDriver<?> driver) {
		super(driver);
		// TODO 自动生成的构造函数存根
	}
    //插件控件的id
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/item_imageView")
	List<AndroidElement> plugImage;

	public List<AndroidElement> getPlugImage() {
		return plugImage;
	}
	//界面返回按钮id
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id = "com.updrv.lifecalendar:id/main_order_top_back")
	AndroidElement backBtn;
	public AndroidElement getBackBtn() {
		return backBtn;
	}
	//删除插件按钮
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="com.updrv.lifecalendar:id/img_edit")
	List<AndroidElement> plugDeleteBtn;
	
	//不显示的插件模块
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="com.updrv.lifecalendar:id/rl_all_otherhead")
	AndroidElement notDisplayWidgit;

	//插件设置页面插件排布窗口
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="com.updrv.lifecalendar:id/recy")
	AndroidElement plugWindow;
	
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(xpath="//android.support.v7.widget.RecyclerView/android.widget.RelativeLayout")
	List<AndroidElement> singlePlug;
	
	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	@FindBy(id="android:id/content")
	AndroidElement cotent;
	
	public AndroidElement getCotent() {
		return cotent;
	}


	public List<AndroidElement> getSinglePlug() {
		return singlePlug;
	}


	public AndroidElement getPlugWindow() {
		return plugWindow;
	}


	public AndroidElement getNotDisplayWidgit() {
		return notDisplayWidgit;
	}


	public List<AndroidElement> getPlugDeleteBtn() {
		return plugDeleteBtn;
	}
	private int note_position = 1;
	private int almanac_position = 2;
	private int weather_position = 3;
	private int horoscop_positon = 4;
	private int historyToday_position = 5;
	
	List<Integer> plugList= new ArrayList<Integer>();
	

	public Map<String, Integer> getPlugPostion(int postion ) {
		Map<String,Integer> plugMap = new LinkedHashMap< String,Integer>();
		plugMap.put("记事",note_position);
		plugMap.put( "黄历",almanac_position);
		plugMap.put( "天气",weather_position);
		plugMap.put( "星座",horoscop_positon);
		plugMap.put( "历史今天",historyToday_position);
//		plugList.add(note_position);
//		plugList.add(almanac_position);
//		plugList.add(weather_position);
//		plugList.add(horoscop_positon);
//		plugList.add(historyToday_position);
		
		TouchAction ta = new TouchAction(driver);
		//int postion = (int)(Math.random()*4);
		//记事控件
		AndroidElement note =plugImage.get(1);
		//记事控件的顶部坐标(初始状态)
		int noteTopX=note.getCenter().x;
		int noteTopY=note.getLocation().y;
		
		//黄历控件
		AndroidElement almanac=plugImage.get(2);
		//黄历控件的底部边缘线的x坐标及y坐标
		int almanacBottomX=almanac.getCenter().x;
		int almaacBottomY=almanac.getLocation().y+almanac.getSize().getHeight();
		
        //天气控件
		AndroidElement weather=plugImage.get(3);
		
		int weatherBottomX=weather.getCenter().x;
		int weatherBottomY=weather.getLocation().y+weather.getSize().getHeight();
		
		
		switch (postion) {
//		case 0:
//			break;
		case 1:
			logger.info("记事跟黄历交换位置..");
			//与下个控件交换位置需要与下个控件的底部边界线对齐
			ta.longPress(note).moveTo(almanacBottomX,almaacBottomY)
					.release().perform();

			plugMap.put("记事",2);
			plugMap.put("黄历", 1);
			for(String key:plugMap.keySet()){
				logger.info("置换后新的顺序为："+"key="+key+"value="+plugMap.get(key));
			}
			
			logger.info("记事跟黄历交换位置完毕,记事的位置坐标为"+plugMap.get("记事"));
			return plugMap;
//			break;
		case 2:
			logger.info("记事跟天气交换位置..");
			ta.longPress(note).moveTo(weatherBottomX,weatherBottomY)
					.release().perform();
			plugMap.put("记事",3);
			plugMap.put("天气", 1);
			
			logger.info("记事跟天气交换位置完毕记事的位置坐标为"+plugMap.get("记事"));
			return plugMap;
			//break;
		
		case 5:
			
			logger.info("黄历跟天气交换位置..");
			ta.longPress(almanac).moveTo(weatherBottomX,weatherBottomY)
					.release().perform();
			plugMap.put("黄历",3);
			plugMap.put("天气", 2);
			
			logger.info("黄历跟天气交换位置完毕记事的位置坐标为"+plugMap.get("黄历"));
			return plugMap;
		}
		return plugMap;
	}

}
