package screen;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.WithTimeout;

public class AboutUsScreen extends AbstractScreen {

	public AboutUsScreen(AppiumDriver<?> driver) {
		super(driver);
	}

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	// 关于我们页面，访问官网、QQ、官方微博等
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/common_itemnormal_container")
	private List<AndroidElement> aboutUs;

	//设置5s的延时
	@WithTimeout(time = 5, unit =TimeUnit.SECONDS)
	// 关于我们页面，访问官网、QQ、官方微博等文本信息
	@AndroidFindBy(id = "com.updrv.lifecalendar:id/common_itemnormal_info")
	private List<AndroidElement> aboutUsText;
	
	public List<AndroidElement> getAboutUsText() {
		return aboutUsText;
	}

	public List<AndroidElement> getAboutUs() {
		return aboutUs;
	}

}
